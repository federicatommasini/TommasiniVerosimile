//
//  visualizeSuggestionViewController.swift
//  DREAM
//
//  Created by Alessandro Verosimile on 07/01/22.
//

import UIKit

class visualizeSuggestionViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return suggestions.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "suggestion", for: indexPath) as! SuggestionTableViewCell
        cell.fullText.text = "\(indexPath.row+1) \(suggestions[indexPath.row].text)"
        cell.fullText.numberOfLines = 0
        cell.fullText.lineBreakMode = .byWordWrapping
        cell.fullText.sizeToFit()
        var len = 0
        if suggestions.count != 0{
            for i in 0...suggestions.count-1{
                if suggestions[i].text.count > len{
                    len = suggestions[i].text.count
                }
            }
        }
        if len > 40{
            tableView.rowHeight = CGFloat(len)
        }else{
            tableView.rowHeight = CGFloat(40)
        }
        return cell
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return 3
    }
    
    var farmer: FarmerDTO!
    var suggestions: [SuggestionDTO]!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var picker: UIPickerView!
    
    var filters = ["Environmental conditions","Used Products","Geographical Zone"]
    var paths = ["suggestionsEnvCondition","suggestionsUsedProducts","suggestionsZone"]
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
        picker.delegate = self
        picker.dataSource = self
        suggestions = [SuggestionDTO]()
        Lib.getRequest(path: "/\(paths[0])/\(self.farmer.id!)" as NSString, responseType: [SuggestionDTO].self){x,code in
            if x != nil {
                self.suggestions.removeAll()
                self.suggestions.append(contentsOf: x!)
                self.tableView.reloadData()
            }
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return filters[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        Lib.getRequest(path: "/\(paths[row])/\(self.farmer.id!)" as NSString, responseType: [SuggestionDTO].self){x,code in
            if x != nil {
                self.suggestions.removeAll()
                self.suggestions.append(contentsOf: x!)
                self.tableView.reloadData()
            }
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
