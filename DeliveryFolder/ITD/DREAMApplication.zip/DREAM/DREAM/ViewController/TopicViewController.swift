//
//  TopicViewController.swift
//  DREAM
//
//  Created by Alessandro Verosimile on 27/01/22.
//

import UIKit

class TopicViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, UITextViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return discussion.posts.count+1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.row == discussion.posts.count {
            let cell = tableView.dequeueReusableCell(withIdentifier: "addPost", for: indexPath) as! AddPostTableViewCell
            cell.textField.layer.borderWidth = 1
            cell.textField.layer.cornerRadius = 3
            cell.textField.layer.borderColor = UIColor.gray.cgColor
            cell.textField.textColor = UIColor.lightGray
            cell.textField.delegate = self
            return cell
        }else{
            let cell = tableView.dequeueReusableCell(withIdentifier: "post", for: indexPath) as! PostTableViewCell
            cell.post.text = discussion.posts[indexPath.row].text
            cell.updatedBy.text = "Uploaded by: \(discussion.posts[indexPath.row].writtenBy.name) \(discussion.posts[indexPath.row].writtenBy.surname)"
            return cell
        }
    }
    
    @IBOutlet weak var discussionTitle: UILabel!
    @IBOutlet weak var tableView: UITableView!
    var discussion: DiscussionForumDTO!
    var farmer: FarmerDTO!
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
        discussionTitle.text = discussion.topic
        // Do any additional setup after loading the view.
    }
    
    func textViewDidBeginEditing(_ textView: UITextView) {
        let cell = tableView.cellForRow(at: IndexPath(row: discussion.posts.count, section: 0)) as! AddPostTableViewCell
        if cell.textField.textColor == UIColor.lightGray {
            cell.textField.textColor = UIColor.black
            cell.textField.text = ""
        }
    }
    
    /*func textViewDidEndEditing(_ textView: UITextView) {
        DispatchQueue.main.asyncAfter(deadline: .now()+2.0) {
            let cell = self.tableView.cellForRow(at: IndexPath(row: self.discussion.posts.count, section: 0)) as! AddPostTableViewCell
            if cell.textField.text.isEmpty {
                textView.text = "Insert here your comment"
                textView.textColor = UIColor.lightGray
            }
        }
    }*/
    
    private func textFieldShouldReturn(textField: UITextField) -> Bool {
            textField.resignFirstResponder()
            return true
        }


    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    @IBAction func updateComment(_ sender: Any) {
        let cell = tableView.cellForRow(at: IndexPath(row: discussion.posts.count, section: 0)) as! AddPostTableViewCell
        if cell.textField.text == ""{
            let errorAlert = UIAlertController(title: "Oh no!", message: "The search field is empty", preferredStyle: .alert)
            errorAlert.addAction(UIAlertAction(title: "OK", style: .default) { action in
                print("empty fields")
            })
            self.present(errorAlert, animated: true, completion: nil)
        }else{
            let errorAlert = UIAlertController(title: "Perfect!", message: "Your post has been updated correctly", preferredStyle: .alert)
            errorAlert.addAction(UIAlertAction(title: "OK", style: .default) { action in
                //cell.textField.text = ""
            })
            self.discussion.posts.append(ForumPostDTO(text: cell.textField.text, writtenBy: self.farmer))
            self.tableView.reloadData()
            
            cell.textField.text = "Insert here your comment"
            cell.textField.textColor = UIColor.lightGray
            self.present(errorAlert, animated: true, completion: nil)
            let post = ForumPostDTO(text: discussion.posts.last!.text, writtenBy: self.farmer)
            Lib.postJSONRequestWithoutResponse(path: "/discussionForumPosts/\(self.discussion.id!)/\(self.farmer.id!)" as NSString, httpBody: post, completionFunction: nil)
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
