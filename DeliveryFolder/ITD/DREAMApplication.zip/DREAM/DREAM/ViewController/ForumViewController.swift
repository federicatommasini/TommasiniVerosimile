//
//  ForumViewController.swift
//  DREAM
//
//  Created by Alessandro Verosimile on 26/01/22.
//

import UIKit

class ForumViewController: UIViewController {

    var farmer: FarmerDTO!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        switch segue.identifier {
        case "create": do{
            let dst = segue.destination as! CreateForumViewController
            dst.farmer = farmer
            break
        }
        case "visualizeForum": do{
            let dst = segue.destination as! visualizeForumViewController
            dst.farmer = farmer
            break
        }
        case .none:
            print("no segue")
        case .some(_):
            print("too many segues")
        }
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }

}
