//
//  ProductUsedTableViewController.swift
//  DREAM
//
//  Created by Alessandro Verosimile on 26/01/22.
//

import UIKit

class ProductUsedTableViewController: UITableViewController {

    var farmer: FarmerDTO!
    var usedProducts = [UsedProductDTO]()
    var initialUsedProducts = [UsedProductDTO]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    private func textFieldShouldReturn(textField: UITextField) -> Bool {
            textField.resignFirstResponder()
            return true
        }


    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return usedProducts.count + 1
    }
    
    
    @IBAction func saveProducts(_ sender: Any) {
        let count = usedProducts.count
        if count != 0 {
            for i in 0...count-1{
                if usedProducts[count-1-i].name == ""{
                    usedProducts.remove(at: count-1-i)
                }
            }
        }
        var i = 0
        for product in usedProducts {
            if !(initialUsedProducts.contains(product)){
                DispatchQueue.main.asyncAfter(deadline: .now()+0.2*Double(i)){
                    Lib.putJSONRequestWithoutResponse(path: "/usedProducts/add/\(self.farmer.id!)" as NSString, httpBody: product, completionFunction: {
                        print("aggiungo \(product.name)")
                    })
                }
                i=i+1
            }
        }
        for product in initialUsedProducts {
            if !(usedProducts.contains(product)){
                DispatchQueue.main.asyncAfter(deadline: .now()+0.2*Double(i)){
                    Lib.deleteWithoutResponse(path: "/usedProducts/delete/\(self.farmer.id!)/\(product.name)" as NSString, completionFunction: {
                        print("rimuovo \(product.name)")
                    })
                }
                i = i+1
            }
        }
        let errorAlert = UIAlertController(title: "", message: "Your data have been saved correctly", preferredStyle: .alert)
        errorAlert.addAction(UIAlertAction(title: "OK", style: .default) { action in
            self.navigationController?.popViewController(animated: true)
        })
        self.present(errorAlert, animated: true, completion: nil)
        
        self.tableView.reloadData()
        
    }
    
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.row == usedProducts.count {
            let cell = tableView.dequeueReusableCell(withIdentifier: "plus", for: indexPath) as! PlusTableViewCell
            return cell
        }else{
            let cell = tableView.dequeueReusableCell(withIdentifier: "usedProduct", for: indexPath) as! UsedProductTableViewCell
            cell.product.text = usedProducts[indexPath.row].name
            cell.product.tag = indexPath.row
            return cell
        }
    }
    
    @IBAction func editingEnd(_ sender: UITextField) {
        usedProducts[sender.tag].name = sender.text!
    }
    
    @IBAction func addProduct(_ sender: Any) {
        usedProducts.append(UsedProductDTO(name: ""))
        self.tableView.reloadData()
    }
    
    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            usedProducts.remove(at: indexPath.row)
            if usedProducts.count != 0{
                for i in 0...usedProducts.count-1 {
                    if i>indexPath.row {
                        let cell = tableView.dequeueReusableCell(withIdentifier: "usedProduct", for: indexPath) as! UsedProductTableViewCell
                        cell.product.tag = cell.product.tag-1
                    }
                }
            }
            
            tableView.deleteRows(at: [indexPath], with: .fade)
        }
    }
    

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
