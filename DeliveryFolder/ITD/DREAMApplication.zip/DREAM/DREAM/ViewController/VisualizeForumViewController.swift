//
//  forumViewController.swift
//  DREAM
//
//  Created by Alessandro Verosimile on 07/01/22.
//

import UIKit

class visualizeForumViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return topics.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "topic", for: indexPath) as! TopicTableViewCell
        cell.titleButton.setTitle(topics[indexPath.row].topic, for: .normal)
        if topics[indexPath.row].posts.count != 0{
            cell.firstMessage.text = topics[indexPath.row].posts[0].text
        }else{
            cell.firstMessage.text = ""
        }
        cell.stack.layer.borderWidth = 2
        cell.stack.layer.borderColor = UIColor.orange.cgColor
        cell.stack.layer.cornerRadius = 10
        return cell
    }
    
    var topics: [DiscussionForumDTO]!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var textField: UITextField!
    @IBOutlet weak var topicsIndication: UILabel!
    var farmer: FarmerDTO!
    override func viewDidLoad() {
        super.viewDidLoad()
        topicsIndication.isHidden = true
        tableView.delegate = self
        tableView.dataSource = self
        
        topics = [DiscussionForumDTO]()
        // Do any additional setup after loading the view.
    }
    
    private func textFieldShouldReturn(textField: UITextField) -> Bool {
            textField.resignFirstResponder()
            return true
        }


    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    @IBAction func search(_ sender: Any) {
        if textField.text == "" {
            let errorAlert = UIAlertController(title: "Oh no!", message: "The search field is empty", preferredStyle: .alert)
            errorAlert.addAction(UIAlertAction(title: "OK", style: .default) { action in
                print("empty fields")
            })
            self.present(errorAlert, animated: true, completion: nil)
        }else{
            Lib.getRequest(path: "/searchDiscussionForums/\(self.textField.text!)" as NSString, responseType: [DiscussionForumDTO].self){x,code in
                if x != nil {
                    self.topics.removeAll()
                    self.topics.append(contentsOf: x!)
                    if !(self.topics.isEmpty){
                        self.topicsIndication.isHidden = false
                    }else{
                        self.topicsIndication.isHidden = true
                    }
                    self.tableView.reloadData()
                }
            }
        }
    }
    

    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let dst = segue.destination as! TopicViewController
        let index = tableView.indexPathForSelectedRow!.row
        dst.discussion = topics[index]
        dst.farmer = farmer
    }
    

}
