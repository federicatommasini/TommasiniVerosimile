//
//  SuggestionViewController.swift
//  DREAM
//
//  Created by Alessandro Verosimile on 26/01/22.
//

import UIKit

class SuggestionViewController: UIViewController {

    var farmer: FarmerDTO!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        switch segue.identifier {
        case "upload": do{
            let dst = segue.destination as! uploadSuggestionViewController
            dst.farmer = farmer
            break
        }
        case "visualize": do{
            let dst = segue.destination as! visualizeSuggestionViewController
            dst.farmer = farmer
            break
        }
        case .none:
            print("no segue")
        case .some(_):
            print("too many segues")
        }
    }
    

}
