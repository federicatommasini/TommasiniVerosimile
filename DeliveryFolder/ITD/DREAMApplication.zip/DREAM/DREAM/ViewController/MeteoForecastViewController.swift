//
//  MeteoForecastViewController.swift
//  DREAM
//
//  Created by Alessandro Verosimile on 26/01/22.
//

import UIKit

class MeteoForecastViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    var farmer: FarmerDTO!
    var dataSource = [MeteoForecastDTO]()
    @IBOutlet weak var date: UIDatePicker!
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return dataSource.count + 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "meteo", for: indexPath) as! MeteoTableViewCell
        if indexPath.row != 0{
            cell.hour.text = String(dataSource[indexPath.row-1].day.suffix(5))
            cell.temperature.text = "\(dataSource[indexPath.row-1].temperature)"
            cell.humidity.text = "\(dataSource[indexPath.row-1].humidity)"
            cell.rainfalls.text = "\(dataSource[indexPath.row-1].rainfalls)"
        }else{
            cell.hour.text = "Hour"
            cell.temperature.text = "T: C"
            cell.humidity.text = "Hum:"
            cell.rainfalls.text = "Rainfalls:"
        }
        return cell
        
    }
    
    
    @IBOutlet weak var datePicker: UIDatePicker!
    @IBOutlet weak var cityLabel: UILabel!
    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //cityLabel.text = farmer.farm.city
        tableView.delegate = self
        tableView.dataSource = self
        self.tableView.reloadData()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func changeDate(_ sender: Any) {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        let day = dateFormatter.string(from: datePicker.date)
        Lib.getRequest(path: "/meteoForecasts/\(self.farmer.farm.city)/\(day)" as NSString, responseType: [MeteoForecastDTO].self){x,code in
            if x != nil {
                self.dataSource.removeAll()
                self.dataSource.append(contentsOf: x!)
                self.tableView.reloadData()
            }
        }
        self.tableView.reloadData()
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
