//
//  SignUpViewController.swift
//  DREAM
//
//  Created by Alessandro Verosimile on 28/01/22.
//

import UIKit

class SignUpViewController: UIViewController {

    
    @IBOutlet weak var email: UITextField!
    @IBOutlet weak var name: UITextField!
    @IBOutlet weak var surname: UITextField!
    @IBOutlet weak var password: UITextField!
    @IBOutlet weak var confirmPassword: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        password.textContentType = UITextContentType(rawValue: "password")
        confirmPassword.textContentType = UITextContentType(rawValue: "password")
        navigationItem.hidesBackButton = true
        // Do any additional setup after loading the view.
    }
    
    private func textFieldShouldReturn(textField: UITextField) -> Bool {
            textField.resignFirstResponder()
            return true
        }


    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    @IBAction func returnToLogIn(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    func strongPassword(_ password:String)->Int{
        if password.count<8 {
            return 1
        }else if !(password.contains(where: {$0.isNumber})) || !(password.contains(where: {$0.isLetter})){
            return 2
        }
        return 0
    }
    
    /*
    func isValidEmail(_ email: String) -> Bool {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        let emailPred = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailPred.evaluate(with: email)
    }*/
    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if email.text!.isEmpty || name.text!.isEmpty || surname.text!.isEmpty || password.text!.isEmpty || confirmPassword.text!.isEmpty {
            let errorAlert = UIAlertController(title: "Oh no!", message: "One of the field is empty", preferredStyle: .alert)
            errorAlert.addAction(UIAlertAction(title: "OK", style: .default) { action in
                print("empty fields")
            })
            self.present(errorAlert, animated: true, completion: nil)
        }else{
            if(password.text! != confirmPassword.text!){
                let errorAlert = UIAlertController(title: "Oh no!", message: "Your passwords don't match", preferredStyle: .alert)
                errorAlert.addAction(UIAlertAction(title: "OK", style: .default) { action in
                    print("empty fields")
                })
                self.present(errorAlert, animated: true, completion: nil)
            }else{
                if strongPassword(password.text!)==1{
                    let errorAlert = UIAlertController(title: "Oh no!", message: "Your password must be long at least 8", preferredStyle: .alert)
                    errorAlert.addAction(UIAlertAction(title: "OK", style: .default) { action in
                        print("short password")
                    })
                    self.present(errorAlert, animated: true, completion: nil)
                }else if strongPassword(password.text!)==2{
                    let errorAlert = UIAlertController(title: "Oh no!", message: "Your password must contain at least 1 number and 1 letter", preferredStyle: .alert)
                    errorAlert.addAction(UIAlertAction(title: "OK", style: .default) { action in
                        print("not letter and number")
                    })
                }else{
                    let farmer = FarmerDTO(email: email.text!, name: name.text!, surname: surname.text!, status: "NORMAL", pw: password.text!)
                    let dst = segue.destination as! SignUp2ViewController
                    dst.farmer = farmer
                }
            }
        }
    }
    

}
