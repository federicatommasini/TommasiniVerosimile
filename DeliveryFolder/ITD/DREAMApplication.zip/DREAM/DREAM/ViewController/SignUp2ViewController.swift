//
//  SignUp2ViewController.swift
//  DREAM
//
//  Created by Alessandro Verosimile on 28/01/22.
//

import UIKit

class SignUp2ViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return 10
    }
    

    var farmer: FarmerDTO!
    let zones = ["Adilabad","Hyderabad","Karimnagar","Khammam","Mahbubnagar","Medak","Nalgonda","Nizamabad","Rangareddy","Warangal"]
    var selectedZone = "Adilabad"
    @IBOutlet weak var zonePicker: UIPickerView!
    @IBOutlet weak var name: UITextField!
    @IBOutlet weak var city: UITextField!
    @IBOutlet weak var size: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        zonePicker.delegate = self
        zonePicker.dataSource = self

        // Do any additional setup after loading the view.
    }
    
    private func textFieldShouldReturn(textField: UITextField) -> Bool {
            textField.resignFirstResponder()
            return true
        }


    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return zones[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        selectedZone = zones[row]
    }
    

    
    // MARK: - Navigation
    
    override func shouldPerformSegue(withIdentifier identifier: String, sender: Any?) -> Bool {
        switch identifier {
        case "goHome":
            if name.text!.isEmpty || city.text!.isEmpty || size.text!.isEmpty {
                let errorAlert = UIAlertController(title: "Oh no!", message: "One of the field is empty", preferredStyle: .alert)
                errorAlert.addAction(UIAlertAction(title: "OK", style: .default) { action in
                    print("empty fields")
                })
                self.present(errorAlert, animated: true, completion: nil)
            }else{
                let farm = FarmDTO(name: name.text!, soilCondition: "NORMAL", meteoCondition: "NORMAL", city: city.text!, geographicalZone: selectedZone, size: Int(size.text!)!)
                farmer.farm = farm
                Lib.getRequest(path: "/checkRegCredentials/\(farmer.email)" as NSString, responseType: Bool.self){x,code in
                    if x! {
                        Lib.postJSONRequestWithResponse("/registration", self.farmer, responseType: FarmerDTO.self){x,code in
                            let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
                            let nextViewController = storyBoard.instantiateViewController(withIdentifier: "home") as! HomeViewController
                            self.navigationController?.pushViewController(nextViewController, animated: true)
                            nextViewController.farmer = x!
                            Lib.postJSONRequestWithoutResponse(path: "/associateCondition/\(x!.id!)" as NSString, httpBody: x!,completionFunction: nil)
                        }
                    }else{
                        let errorAlert = UIAlertController(title: "Oh no!", message: "An account with this email already exists, change email", preferredStyle: .alert)
                        errorAlert.addAction(UIAlertAction(title: "OK", style: .default) { action in
                            print("account already exists")
                        })
                        self.present(errorAlert, animated: true, completion: nil)
                    }
                }
                    
            }
        case "goRegistration":
            return true
        default:
            print("no segue")
        }
        return false
    }

/*
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
 */
}
