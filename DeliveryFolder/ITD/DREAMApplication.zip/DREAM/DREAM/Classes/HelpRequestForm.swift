//
//  HelpRequestFormDTO.swift
//  DREAM
//
//  Created by Alessandro Verosimile on 27/01/22.
//

import Foundation

struct HelpRequestForm: Codable{
    var problemDescription: String
    var askedBy: FarmerDTO!
}
