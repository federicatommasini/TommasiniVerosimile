//
//  MeteoForecastsDTO.swift
//  DREAM
//
//  Created by Alessandro Verosimile on 27/01/22.
//

import Foundation

struct MeteoForecastDTO: Codable{
    var id: Int!
    var day: String
    var location: String
    var temperature: Double
    var humidity: Double
    var rainfalls: Double
    
    init (day: String, temperature: Double, humidity: Double, rainfalls: Double, location: String){
        self.day = day
        self.temperature = temperature
        self.humidity = humidity
        self.rainfalls = rainfalls
        self.location = location
    }
}
