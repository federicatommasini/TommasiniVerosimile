//
//  UsedProductDTO.swift
//  DREAM
//
//  Created by Alessandro Verosimile on 27/01/22.
//

import Foundation

struct UsedProductDTO: Codable,Equatable{
    var name: String
}
