//
//  SuggestionDTO.swift
//  DREAM
//
//  Created by Alessandro Verosimile on 27/01/22.
//

import Foundation


struct SuggestionDTO: Codable{
    var id: Int!
    var text: String
    var uploadedBy: FarmerDTO!
}
