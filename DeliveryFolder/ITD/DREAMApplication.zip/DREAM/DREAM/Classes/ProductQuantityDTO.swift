//
//  ProductQuantityDTO.swift
//  DREAM
//
//  Created by Alessandro Verosimile on 21/01/22.
//

import Foundation

struct ProductQuantityDTO: Codable,Equatable{
    var id: Int!
    var productName: String
    var quantity: Double
}
