//
//  FarmDTO.swift
//  DREAM
//
//  Created by Alessandro Verosimile on 26/01/22.
//

import Foundation

struct FarmDTO: Codable{
    var id: Int!
    var name: String
    var soilCondition: String
    var meteoCondition: String
    var city: String
    var geographicalZone: String
    var size: Int
}
