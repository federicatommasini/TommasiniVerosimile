//
//  FarmerDTO.swift
//  DREAM
//
//  Created by Alessandro Verosimile on 26/01/22.
//

import Foundation

struct FarmerDTO: Codable{
    var id: Int!
    var email: String
    var name: String
    var surname: String
    var status: String
    var pw: String
    var farm: FarmDTO!
    
    init (email: String, name: String, surname: String, status: String, pw: String){
        self.email = email
        self.name = name
        self.surname = surname
        self.status = status
        self.pw = pw
    }
}
