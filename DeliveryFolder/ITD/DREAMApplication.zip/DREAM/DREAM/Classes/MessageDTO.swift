//
//  MessageDTO.swift
//  DREAM
//
//  Created by Alessandro Verosimile on 27/01/22.
//

import Foundation

struct MessageDTO:Codable{
    var id : Int!
    var text: String
    var sender: FarmerDTO!
    var receiver: FarmerDTO!
    var request: Int!
    var answered: Int!
}
