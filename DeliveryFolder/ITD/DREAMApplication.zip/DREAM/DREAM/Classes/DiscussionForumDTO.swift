//
//  DiscussionForumDTO.swift
//  DREAM
//
//  Created by Alessandro Verosimile on 27/01/22.
//

import Foundation

struct DiscussionForumDTO : Codable{
    var id: Int!
    var topic: String
    var posts: [ForumPostDTO]!
}
