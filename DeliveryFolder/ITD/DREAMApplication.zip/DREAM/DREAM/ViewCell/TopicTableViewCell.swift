//
//  TopicTableViewCell.swift
//  DREAM
//
//  Created by Alessandro Verosimile on 27/01/22.
//

import UIKit

class TopicTableViewCell: UITableViewCell {

    @IBOutlet weak var stack: UIStackView!
    @IBOutlet weak var titleButton: UIButton!
    @IBOutlet weak var firstMessage: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
