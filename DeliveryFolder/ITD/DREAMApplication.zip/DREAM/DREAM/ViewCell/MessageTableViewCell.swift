//
//  MessageTableViewCell.swift
//  DREAM
//
//  Created by Alessandro Verosimile on 08/01/22.
//

import UIKit

class MessageTableViewCell: UITableViewCell {

    @IBOutlet weak var farmer: UILabel!
    @IBOutlet weak var message: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
