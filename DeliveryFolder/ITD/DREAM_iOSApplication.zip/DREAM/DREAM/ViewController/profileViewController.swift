//
//  profileViewController.swift
//  DREAM
//
//  Created by Alessandro Verosimile on 21/12/21.
//

import UIKit

class profileViewController: UIViewController,UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    var farmer: FarmerDTO!
    @IBOutlet weak var email: UILabel!
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var surname: UILabel!
    @IBOutlet weak var farm: UILabel!
    @IBOutlet weak var size: UILabel!
    @IBOutlet weak var status: UILabel!
    @IBOutlet weak var image: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        email.text = "Email: \(farmer.email)"
        name.text = "Name: \(farmer.name)"
        surname.text = "Surname: \(farmer.surname)"
        farm.text = "Farm: \(farmer.farm.name)"
        size.text = "Size: \(farmer.farm.size)"
        status.text = farmer.status.uppercased()
        if farmer.status.uppercased() == "GOOD" {
            status.textColor = UIColor.green
        }
        if farmer.status.uppercased() == "NORMAL" {
            status.textColor = UIColor.black
        }
        if farmer.status.uppercased() == "BAD" {
            status.textColor = UIColor.red
        }
        image.layer.borderWidth = 1
        image.layer.masksToBounds = false
        image.layer.borderColor = UIColor.systemBackground.cgColor
        image.layer.cornerRadius = image.frame.height/2
        image.clipsToBounds = true
    }
    
    @IBAction func logout(_ sender: Any) {
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
        let startViewController = storyBoard.instantiateViewController(withIdentifier: "login") as! LogInViewController
        let errorAlert = UIAlertController(title: "Logout", message: "Are you sure to logout?", preferredStyle: .alert)
        errorAlert.addAction(UIAlertAction(title: "OK", style: .destructive) { action in
            self.navigationController?.pushViewController(startViewController, animated: true)
        })
        errorAlert.addAction(UIAlertAction(title: "Cancel", style: .default) { action in
            print("cancel")
        })
        self.present(errorAlert, animated: true, completion: nil)
    }
    
    @IBAction func editImage(_ sender: Any) {
        let alert = UIAlertController(title: "Edit Profile Image", message: "Please Select an Option", preferredStyle: .actionSheet)
            
            alert.addAction(UIAlertAction(title: "Take a photo", style: .default , handler:{ (UIAlertAction)in
                print("User click Take a Photo button")
                self.takeAPhoto()
                
            }))
            alert.addAction(UIAlertAction(title: "Select from Library", style: .default , handler:{ (UIAlertAction)in
                print("User click Select from Library button")
                self.selectFromLibrary()
                
            }))
            alert.addAction(UIAlertAction(title: "Remove Image", style: .destructive , handler:{ (UIAlertAction)in
                print("User click Remove Image button")
                self.image.image = UIImage(named:"default_user.png")
                
            }))
            alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler:{ (UIAlertAction)in
                print("User click Dismiss button")
            }))

            alert.actions[0].isEnabled = UIImagePickerController.isSourceTypeAvailable(.camera)
            alert.actions[1].isEnabled = UIImagePickerController.isSourceTypeAvailable(.photoLibrary)
        
            self.present(alert, animated: true, completion: {
                print("completion block")
            })}
    
    
    func takeAPhoto (){
        let imagePicker = UIImagePickerController()
        
        imagePicker.allowsEditing = true;

            imagePicker.sourceType = .camera
            
            let pickerFrame = CGRect(x: 0, y: 22, width: imagePicker.view.bounds.width, height: imagePicker.view.bounds.height - imagePicker.navigationBar.bounds.size.height - imagePicker.toolbar.bounds.size.height - 55)
 
            UIGraphicsBeginImageContext(pickerFrame.size)
            let context = UIGraphicsGetCurrentContext()
            
            context!.saveGState()
            context!.setStrokeColor(red: 1, green: 1, blue: 0, alpha: 1)
            context!.setLineWidth(1)
            let cx = pickerFrame.width/2
            let cy = pickerFrame.height/2
            context!.move(to: CGPoint.init(x: cx, y: cy - 40))
            context!.addLine(to: CGPoint.init(x: cx, y: cy + 40))
            context!.move(to: CGPoint.init(x: cx - 40, y: cy))
            context!.addLine(to: CGPoint.init(x: cx + 40, y: cy))
            context!.drawPath(using : .fillStroke)
            context!.restoreGState()
            
            
            let overlayImage = UIGraphicsGetImageFromCurrentImageContext()
            UIGraphicsEndImageContext();
            
            let overlayView = UIImageView(frame: pickerFrame)
            overlayView.image = overlayImage
            imagePicker.cameraOverlayView = overlayView
            imagePicker.modalPresentationStyle = .popover
        
        imagePicker.delegate = self
        
        present(imagePicker, animated: true, completion: nil)
    }
    
    
    func selectFromLibrary(){
        let imagePicker = UIImagePickerController()
        imagePicker.allowsEditing = true;
        imagePicker.sourceType = .photoLibrary
        imagePicker.delegate = self

        present(imagePicker, animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController,
        didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey: Any]) {
        let info = convertFromUIImagePickerControllerInfoKeyDictionary(info)
  
        let image2 = info[convertFromUIImagePickerControllerInfoKey(UIImagePickerController.InfoKey.editedImage)] as! UIImage

            image.image = image2
            dismiss(animated: true, completion: nil)
    }
    
    
    // Helper function inserted by Swift 4.2 migrator.
    fileprivate func convertFromUIImagePickerControllerInfoKeyDictionary(_ input: [UIImagePickerController.InfoKey: Any]) -> [String: Any] {
        return Dictionary(uniqueKeysWithValues: input.map {key, value in (key.rawValue, value)})
    }

    // Helper function inserted by Swift 4.2 migrator.
    fileprivate func convertFromUIImagePickerControllerInfoKey(_ input: UIImagePickerController.InfoKey) -> String {
        return input.rawValue
    }
    

    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        switch segue.identifier {
        case "productionQuantities":
            let dst = segue.destination as! ProductQuantityTableViewController
            dst.farmer = farmer
            Lib.getRequest(path: "/getProductions/\(self.farmer.id!)" as NSString, responseType: [ProductQuantityDTO].self){x,code in
                print("ciaooo")
                if (x != nil){
                    dst.products.append(contentsOf: x!)
                    dst.initialProducts.append(contentsOf: x!)
                    dst.tableView.reloadData()
                }
            }
            break
        case "productUsed":
            let dst = segue.destination as! ProductUsedTableViewController
            dst.farmer = farmer
            Lib.getRequest(path: "/getUsedProducts/\(self.farmer.id!)" as NSString, responseType: [UsedProductDTO].self){x,code in
                if (x != nil){
                    dst.usedProducts.append(contentsOf: x!)
                    dst.initialUsedProducts.append(contentsOf: x!)
                    dst.tableView.reloadData()
                }
            }
            break
        case .none:
            print("no segue")
        case .some(_):
            print("too many segues")
        }
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    

}
