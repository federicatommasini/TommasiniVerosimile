//
//  ViewController.swift
//  SEUserInterfaces
//
//  Created by Alessandro Verosimile on 19/12/21.
//

import UIKit

class HomeViewController: UIViewController {

    var farmer: FarmerDTO!

    @IBOutlet weak var stack1: UIStackView!
    @IBOutlet weak var stack2: UIStackView!
    @IBOutlet weak var stack3: UIStackView!
    @IBOutlet weak var stack4: UIStackView!
    override func viewDidLoad() {
        print("User logged with id: \(farmer.id!)")
        super.viewDidLoad()
        stack1.layer.borderWidth = 2
        stack1.layer.borderColor = UIColor.orange.cgColor
        stack1.layer.cornerRadius = 10
        stack2.layer.borderWidth = 2
        stack2.layer.borderColor = UIColor.orange.cgColor
        stack2.layer.cornerRadius = 10
        stack3.layer.borderWidth = 2
        stack3.layer.borderColor = UIColor.orange.cgColor
        stack3.layer.cornerRadius = 10
        stack4.layer.borderWidth = 2
        stack4.layer.borderColor = UIColor.orange.cgColor
        stack4.layer.cornerRadius = 10
        navigationItem.hidesBackButton = true
    }
    
    
    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        switch segue.identifier {
        case "goProfile": do{
            let dst = segue.destination as! profileViewController
            dst.farmer = farmer
            break
        }
        case "goMessages": do{
            let dst = segue.destination as! messagesTableViewController
            dst.farmer = farmer
            break
        }
        case "goMeteo": do {
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "yyyy-MM-dd"
            let day = dateFormatter.string(from: Date.now)
            Lib.getRequest(path: "/meteoForecasts/\(self.farmer.farm.city)/\(day)" as NSString, responseType: [MeteoForecastDTO].self){x,code in
                let dst = segue.destination as! MeteoForecastViewController
                dst.cityLabel.text = self.farmer.farm.city
                dst.farmer = self.farmer
                if x != nil {
                    dst.dataSource.removeAll()
                    dst.dataSource.append(contentsOf: x!)
                    dst.tableView.reloadData()
                }
            }
            break
        }
        case "goSuggestions": do {
            let dst = segue.destination as! SuggestionViewController
            dst.farmer = farmer
            break
        }
        case "goHelp": do {
            let dst = segue.destination as! RequestForHelpViewController
            dst.farmer = farmer
            break
        }
        case "goForum": do {
            let dst = segue.destination as! ForumViewController
            dst.farmer = farmer
            break
        }
        case .none:
            print("no segue")
        case .some(_):
            print("too many segues")
        }
    }
}

