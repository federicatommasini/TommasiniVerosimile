//
//  suggestionViewController.swift
//  DREAM
//
//  Created by Alessandro Verosimile on 07/01/22.
//

import UIKit

class uploadSuggestionViewController: UIViewController {

    
    @IBOutlet weak var suggestionTitle: UITextField!
    @IBOutlet weak var textView: UITextView!
    
    var farmer: FarmerDTO!
    override func viewDidLoad() {
        super.viewDidLoad()

        textView.layer.borderWidth = 1
        textView.layer.cornerRadius = 3
        textView.layer.borderColor = UIColor.gray.cgColor
    }
    

    @IBAction func upload(_ sender: Any) {
        
        if suggestionTitle.text == "" || textView.text == "" {
            let errorAlert = UIAlertController(title: "Oh no!", message: "Fill all the fields to upload the suggestion", preferredStyle: .alert)
            errorAlert.addAction(UIAlertAction(title: "OK", style: .default) { action in
                print("empty fields")
            })
            self.present(errorAlert, animated: true, completion: nil)
        }else{
            let errorAlert = UIAlertController(title: "Perfect!", message: "Your suggestion has been uploaded correctly", preferredStyle: .alert)
            errorAlert.addAction(UIAlertAction(title: "OK", style: .default) { action in
                self.navigationController?.popViewController(animated: true)
            })
            self.present(errorAlert, animated: true, completion: nil)
            let suggestion = SuggestionDTO(text: "\(suggestionTitle.text!) \r\n \(textView.text!)", uploadedBy: self.farmer)
            Lib.postJSONRequestWithoutResponse(path: "/suggestions", httpBody: suggestion, completionFunction: nil)
        }
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
