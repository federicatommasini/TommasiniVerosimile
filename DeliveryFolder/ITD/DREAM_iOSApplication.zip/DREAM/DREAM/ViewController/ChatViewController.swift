//
//  ChatViewController.swift
//  DREAM
//
//  Created by Alessandro Verosimile on 27/01/22.
//

import UIKit

class ChatViewController: UIViewController {

    @IBOutlet weak var sentBy: UILabel!
    @IBOutlet weak var textField: UITextField!
    @IBOutlet weak var message: UILabel!
    @IBOutlet weak var answer: UILabel!
    @IBOutlet weak var sendButton: UIButton!
    var farmerChat: MessageDTO!
    var farmer: FarmerDTO!
    @IBOutlet weak var messageStack: UIStackView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        answer.isHidden = true
        if farmerChat.sender != nil {
            sentBy.text = "\(farmerChat.sender.name) \(farmerChat.sender.surname)"
        }else{
            sentBy.text = "Policy maker"
            sendButton.isHidden = true
            textField.isHidden = true
        }
        if farmerChat.request == 0{
            sendButton.isHidden = true
            textField.isHidden = true
        }
        message.text = "  \(farmerChat.text)"
        message.numberOfLines = 0
        message.lineBreakMode = .byWordWrapping
        message.sizeToFit()
        message.layer.borderColor = UIColor.link.cgColor
        message.layer.borderWidth = 1.5
        message.layer.cornerRadius = 10
        answer.numberOfLines = 0
        answer.lineBreakMode = .byWordWrapping
        answer.sizeToFit()
        answer.layer.borderColor = UIColor.link.cgColor
        answer.layer.borderWidth = 1.5
        answer.layer.cornerRadius = 10
    }
    
    private func textFieldShouldReturn(textField: UITextField) -> Bool {
            textField.resignFirstResponder()
            return true
        }


    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    @IBAction func send(_ sender: Any) {
        if textField.text == ""{
            let errorAlert = UIAlertController(title: "Oh no!", message: "The message is empty", preferredStyle: .alert)
            errorAlert.addAction(UIAlertAction(title: "OK", style: .default) { action in
                print("empty field")
            })
            self.present(errorAlert, animated: true, completion: nil)
        }else{
            let errorAlert = UIAlertController(title: "Perfect!", message: "Request answered correctly", preferredStyle: .alert)
            errorAlert.addAction(UIAlertAction(title: "OK", style: .default) { action in
                self.navigationController?.popViewController(animated: true)
            })
            self.present(errorAlert, animated: true, completion: nil)
            let answerMessage = MessageDTO(text: textField.text!, sender: self.farmer, receiver: self.farmerChat.sender!,request: 0)
            Lib.postJSONRequestWithoutResponse(path: "/setAnswered", httpBody: self.farmerChat!,completionFunction: nil)
            Lib.postJSONRequestWithoutResponse(path: "/messages/add", httpBody: answerMessage,completionFunction: nil)
            self.answer.isHidden = false
            self.answer.text = "\(self.textField.text!)  "
            self.textField.text = ""
        }
    }
    
    @IBAction func moveStack(_ sender: Any) {
        UIView.animate(withDuration: 0.3){
            self.messageStack.frame.origin = CGPoint(x: 0, y: -290)
        }
    }
    
    @IBAction func moveStackDown(_ sender: Any) {
        UIView.animate(withDuration: 0.3){
            self.messageStack.frame.origin = CGPoint(x: 0, y: 0)
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
