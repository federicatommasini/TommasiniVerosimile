//
//  CreateForumViewController.swift
//  DREAM
//
//  Created by Alessandro Verosimile on 26/01/22.
//

import UIKit

class CreateForumViewController: UIViewController {

    
    var farmer: FarmerDTO!
    
    @IBOutlet weak var titleField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        

        // Do any additional setup after loading the view.
    }
    
    @IBAction func create(_ sender: Any) {
        if titleField.text == ""{
            let errorAlert = UIAlertController(title: "Oh no!", message: "Fill the field to create the discussion", preferredStyle: .alert)
            errorAlert.addAction(UIAlertAction(title: "OK", style: .default) { action in
                print("empty field")
                })
                self.present(errorAlert, animated: true, completion: nil)
        }else{
            let errorAlert = UIAlertController(title: "Perfect!", message: "Your discussion has been created correctly", preferredStyle: .alert)
            errorAlert.addAction(UIAlertAction(title: "OK", style: .default) { action in
                    self.navigationController?.popViewController(animated: true)
            })
            self.present(errorAlert, animated: true, completion: nil)
            let discussion = DiscussionForumDTO(topic: titleField.text!, posts: [ForumPostDTO]())
            Lib.postJSONRequestWithoutResponse(path: "/discussionForums/\(self.farmer.id!)" as NSString, httpBody: discussion, completionFunction: nil)
        }
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
