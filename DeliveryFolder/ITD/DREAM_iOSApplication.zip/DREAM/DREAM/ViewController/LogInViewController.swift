//
//  LogInViewController.swift
//  DREAM
//
//  Created by Alessandro Verosimile on 26/01/22.
//

import UIKit

struct Keys{
    static let prefix = "boh"
    static let email = "email"
    static let password = "password"
    static let saveCredentials = "saveCredentials"
}

class LogInViewController: UIViewController {
    
    var dontAsk = false
    
    let keychain = KeychainSwift(keyPrefix: Keys.prefix)
    
    @IBOutlet weak var email: UITextField!
    @IBOutlet weak var pw: UITextField!
    @IBOutlet weak var saveCredentials: UISwitch!
    
    var farmer: FarmerDTO!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if keychain.getBool(Keys.saveCredentials) ?? false{
            saveCredentials.setOn(true, animated: false)
        }
    }
    
    private func textFieldShouldReturn(textField: UITextField) -> Bool {
            textField.resignFirstResponder()
            return true
        }


    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    @IBAction func autoComplete(_ sender: Any) {
        if (keychain.getBool(Keys.saveCredentials) ?? false) && email.text == "" && pw.text == "" && !dontAsk{
            let alert = UIAlertController(title: "", message: "Do you want to fill automatically?", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Fill", style: .default) { action in
                self.email.text = self.keychain.get(Keys.email)
                self.pw.text = self.keychain.get(Keys.password)
                self.email.backgroundColor = UIColor(red: 255/256, green: 249/256, blue: 166/256, alpha: 1)
                self.pw.backgroundColor = UIColor(red: 255/256, green: 249/256, blue: 166/256, alpha: 1)
            })
            alert.addAction(UIAlertAction(title: "Not now", style: .default) { action in
                self.dontAsk = true
            })
            self.present(alert, animated: true, completion: nil)
        }else{
            dontAsk = false
            self.email.backgroundColor = UIColor.systemBackground
            self.pw.backgroundColor = UIColor.systemBackground
        }
    }
    
    
    // MARK: - Navigation
    
    override func shouldPerformSegue(withIdentifier identifier: String, sender: Any?) -> Bool {
        switch identifier {
        case "goHome":
            if email.text == "" || pw.text == "" {
                let errorAlert = UIAlertController(title: "Oh no!", message: "Your email and/or password are empty", preferredStyle: .alert)
                errorAlert.addAction(UIAlertAction(title: "OK", style: .default) { action in
                    print("empty fields")
                })
                self.present(errorAlert, animated: true, completion: nil)
            }else{
                Lib.getRequest(path: "/login/\(email.text!)/\(pw.text!)" as NSString, responseType: FarmerDTO.self){x,code in
                    if x != nil {
                        self.keychain.set(self.saveCredentials.isOn, forKey: Keys.saveCredentials, withAccess: KeychainSwiftAccessOptions.accessibleWhenUnlocked)
                        self.keychain.set(self.email.text!, forKey: Keys.email, withAccess: KeychainSwiftAccessOptions.accessibleWhenUnlocked)
                        self.keychain.set(self.pw.text!, forKey: Keys.password, withAccess: KeychainSwiftAccessOptions.accessibleWhenUnlocked)
                        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
                        let nextViewController = storyBoard.instantiateViewController(withIdentifier: "home") as! HomeViewController
                        self.navigationController?.pushViewController(nextViewController, animated: true)
                        nextViewController.farmer = x!
                        Lib.postJSONRequestWithoutResponse(path: "/associateCondition/\(x!.id!)" as NSString, httpBody: x!,completionFunction: nil)
                    }else{
                        let errorAlert = UIAlertController(title: "Oh no!", message: "Wrong email or password", preferredStyle: .alert)
                        errorAlert.addAction(UIAlertAction(title: "OK", style: .default) { action in
                            print("wrong email or password")
                        })
                        self.present(errorAlert, animated: true, completion: nil)
                    }
                    
                }
            }
        case "goRegistration":
            return true
        default:
            print("no segue")
        }
        return false
    }
    /*
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
    }
    */
    

}
