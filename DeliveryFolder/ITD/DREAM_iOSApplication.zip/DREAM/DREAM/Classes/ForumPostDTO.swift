//
//  ForumPostDTO.swift
//  DREAM
//
//  Created by Alessandro Verosimile on 27/01/22.
//

import Foundation

struct ForumPostDTO : Codable{
    var id: Int!
    var text: String
    var writtenBy: FarmerDTO!
}
