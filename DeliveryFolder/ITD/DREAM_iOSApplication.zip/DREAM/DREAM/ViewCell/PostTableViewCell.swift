//
//  PostTableViewCell.swift
//  DREAM
//
//  Created by Alessandro Verosimile on 27/01/22.
//

import UIKit

class PostTableViewCell: UITableViewCell {

    @IBOutlet weak var post: UILabel!
    @IBOutlet weak var updatedBy: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
