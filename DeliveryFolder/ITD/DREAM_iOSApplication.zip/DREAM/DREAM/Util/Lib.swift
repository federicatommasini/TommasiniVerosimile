//
//  Lib.swift
//  DREAM
//
//  Created by Alessandro Verosimile on 21/01/22.
//

import Foundation

struct Lib {
    static let ip = "http://localhost:8080"
    
    static func getRequest<T : Codable>(path : NSString, responseType : T.Type, completionFunction : @escaping (T?, Int) -> Void) {
        guard let url = NSURL(string: "\(ip)\(path)") as URL? else {return}
        let request = NSMutableURLRequest(url: url)
        request.httpMethod = "GET"
        request.timeoutInterval = 10
        let session = URLSession(configuration: URLSessionConfiguration.default)
        print("before sending request")
        
        let dataTask = session.dataTask(with: request as URLRequest, completionHandler: { (data, response, error) -> Void in
            
            if let e = error {
                print("Error: \(e)")
            } else {
                print("Request sent correctly")
                guard let responseCode = (response as? HTTPURLResponse)?.statusCode else {return}
                print(responseCode)
                guard let httpData = data else {return}
                do {
                    let decoder = JSONDecoder()
                    let dateFormatter = DateFormatter()
                    dateFormatter.dateFormat = "yyyy-MM-dd hh:mm"
                    decoder.dateDecodingStrategy = .formatted(dateFormatter)
                    let data = try decoder.decode(responseType, from: httpData)
                    DispatchQueue.main.async {
                        completionFunction(data, responseCode)
                    }
                } catch let err {
                    print("error in decoding")
                    print(err.localizedDescription)
                    DispatchQueue.main.async {
                        completionFunction(nil, responseCode)
                    }
                }
            }
        })
        dataTask.resume()
    }
    
    static func postJSONRequestWithoutResponse<U : Codable>(path : NSString, httpBody : U?, completionFunction : (() -> Void)?) {
            postOrPutJSONRequestWithoutResponse(path, httpBody, "POST", completionFunction: completionFunction)
    }
    
    static func putJSONRequestWithoutResponse<U : Codable>(path : NSString, httpBody : U?, completionFunction : (() -> Void)?) {
            postOrPutJSONRequestWithoutResponse(path, httpBody, "PUT", completionFunction: completionFunction)
    }
    
    private static func postOrPutJSONRequestWithoutResponse<U : Codable>(_ path : NSString, _ httpBody : U?, _ mode : String, completionFunction : (() -> Void)?) {
        guard let url = NSURL(string: "\(ip)\(path)") as URL? else {return}
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        let encoder = JSONEncoder()
        encoder.dateEncodingStrategy = .formatted(dateFormatter)
        
        let request = NSMutableURLRequest(url: url)
        request.timeoutInterval = 10
        request.httpMethod = mode

        print("before encoding data")
        if let httpBodyData = httpBody {
            do {
                let requestData = try encoder.encode(httpBodyData)
                request.httpBody = requestData
                request.addValue("application/json", forHTTPHeaderField: "Content-Type")
                print("ok encoding")
            } catch {
                print("Error encoding JSON")
                return
            }
        }
        
        let configuration = URLSessionConfiguration.default
        let session = URLSession(configuration: configuration)
        print("before sending request")
        let dataTask = session.dataTask(with: request as URLRequest, completionHandler: { (data, response, error) -> Void in
            if let e = error {
                print(e)
            } else {
                print("responde code: \(response!)")
                if let c = completionFunction {
                    c()
                }
            }
        })
        dataTask.resume()
    }
    
    static func postJSONRequestWithResponse<U : Codable, T : Codable>(_ path : NSString, _ httpBody : U?, responseType : T.Type, completionFunction : @escaping (T?, Int) -> Void) {
        postOrPutJSONRequestWithResponse(path, httpBody, responseType: responseType, "POST", completionFunction: completionFunction)
    }
    
    static func putJSONRequestWithResponse<U : Codable, T : Codable>(__ path : NSString, _ httpBody : U?, responseType : T.Type, completionFunction : @escaping (T?, Int) -> Void) {
        postOrPutJSONRequestWithResponse(path, httpBody, responseType: responseType, "PUT", completionFunction: completionFunction)
    }
    
    private static func postOrPutJSONRequestWithResponse<U : Codable, T : Codable>(_ path : NSString, _ httpBody : U?, responseType : T.Type, _ mode : String, completionFunction : @escaping (T?, Int) -> Void) {
        guard let url = NSURL(string: "\(ip)\(path)") as URL? else {return}
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        let encoder = JSONEncoder()
        encoder.dateEncodingStrategy = .formatted(dateFormatter)
        
        let request = NSMutableURLRequest(url: url)
        request.timeoutInterval = 10
        request.httpMethod = mode
        
        if let httpBodyData = httpBody {
            do {
                let requestData = try encoder.encode(httpBodyData)
                request.httpBody = requestData
                request.addValue("application/json", forHTTPHeaderField: "Content-Type")
            } catch {
                print("Error encoding JSON")
                return
            }
        }
        
        let configuration = URLSessionConfiguration.default
        let session = URLSession(configuration: configuration)
        let dataTask = session.dataTask(with: request as URLRequest, completionHandler: { (data, response, error) -> Void in
            if let e = error {
                print(e)
            } else {
                guard let responseCode = (response as? HTTPURLResponse)?.statusCode else {return}
                guard let httpData = data else {return}
                do {
                    let decoder = JSONDecoder()
                    let dateFormatter = DateFormatter()
                    dateFormatter.dateFormat = "yyyy-MM-dd"
                    decoder.dateDecodingStrategy = .formatted(dateFormatter)
                    let data = try decoder.decode(responseType, from: httpData)
                    
                    DispatchQueue.main.async {
                        completionFunction(data, responseCode)
                    }
                } catch {
                    DispatchQueue.main.async {
                        completionFunction(nil, responseCode)
                    }
                }
            }
        })
        dataTask.resume()
    }
    
    static func deleteWithoutResponse(path : NSString, completionFunction : (() -> Void)?) {
        guard let url = NSURL(string: "\(ip)\(path)") as URL? else {return}
        let request = NSMutableURLRequest(url: url)
        request.timeoutInterval = 10
        request.httpMethod = "DELETE"
        let configuration = URLSessionConfiguration.default
        let session = URLSession(configuration: configuration)
        let dataTask = session.dataTask(with: request as URLRequest, completionHandler: { (data, response, error) -> Void in
            if let e = error {
                print(e)
            } else {
                print(response!)
                if let c = completionFunction {
                    c()
                }
            }
        })
        dataTask.resume()
    }
}
