package com.TommasiniVerosimile.Dream;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DreamApplicationTests {

	@Test
	void contextLoads() {
	}

}
