package com.TommasiniVerosimile.Dream.controller;

import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.TommasiniVerosimile.Dream.bean.Farmer;
import com.TommasiniVerosimile.Dream.bean.HelpRequestForm;
import com.TommasiniVerosimile.Dream.modelDTO.FarmerDTO;
import com.TommasiniVerosimile.Dream.modelDTO.HelpRequestFormDTO;
import com.TommasiniVerosimile.Dream.repository.FarmerRepository;
import com.TommasiniVerosimile.Dream.repository.HelpRequestFormRepository;

@SpringBootTest
public class HelpRequestFormControllerTest {

	@Autowired
	private HelpRequestFormController helpRequestController;
	@Autowired 
	private FarmerRepository farmerRepo;
	@Autowired
	private HelpRequestFormRepository helpRequestRepository;
	
	@Test
	public void addRequestFormTest() {
		HelpRequestFormDTO hpfDTO=new HelpRequestFormDTO();
		Farmer sender = farmerRepo.findFarmerById(1);
		FarmerDTO send=new FarmerDTO(sender);
		hpfDTO.setProblemDescription("someProblem");
		hpfDTO.setAskedBy(send);
		helpRequestController.addHelpRequestForm(hpfDTO);
		List<HelpRequestForm> hpf=(List<HelpRequestForm>)helpRequestRepository.findAll();
		boolean check=false;
		for(HelpRequestForm h: hpf) {
			if(h.getAskedBy().getId()==sender.getId() && h.getProblemDescription().equals("someProblem"))
				check=true;
		}
		Assertions.assertTrue(check);
	}
}
