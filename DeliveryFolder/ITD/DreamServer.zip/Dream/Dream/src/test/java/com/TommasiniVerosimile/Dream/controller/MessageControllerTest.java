package com.TommasiniVerosimile.Dream.controller;

import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.TommasiniVerosimile.Dream.bean.Farmer;
import com.TommasiniVerosimile.Dream.modelDTO.FarmerDTO;
import com.TommasiniVerosimile.Dream.modelDTO.MessageDTO;
import com.TommasiniVerosimile.Dream.repository.FarmerRepository;

@SpringBootTest
public class MessageControllerTest {

	@Autowired
	private MessageController messageController;
	@Autowired
	private FarmerRepository farmerRepo;
	
	@Test
	public void getAllMessagesTest() {
		Integer idFarmer = 1;
		List<MessageDTO> msg=messageController.getAllMessages(idFarmer);
		for(MessageDTO m: msg) {
			Assertions.assertEquals(m.getReceiver().getId(), idFarmer);
		}
	}
	
	@Test 
	public void addMessageTest() {
		MessageDTO msg=new MessageDTO();
		Farmer receiver = farmerRepo.findFarmerById(1);
		Farmer sender = farmerRepo.findFarmerById(1);
		FarmerDTO rec=new FarmerDTO(receiver);
		FarmerDTO send=new FarmerDTO(sender);
		msg.setText("someText");
		msg.setReceiver(rec);
		msg.setSender(send);
		messageController.addMessage(msg);
		List<MessageDTO> msgForRec=messageController.getAllMessages(rec.getId());
		boolean check=false;
		for(MessageDTO m: msgForRec) {
			if(m.getText().equals(msg.getText()) && m.getSender().getId()==send.getId())
				check=true;
				
		}
		Assertions.assertTrue(check);
	}
}
