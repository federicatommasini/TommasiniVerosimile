package com.TommasiniVerosimile.Dream.controller;

import java.util.List;

import javax.transaction.Transactional;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.TommasiniVerosimile.Dream.bean.Farmer;
import com.TommasiniVerosimile.Dream.bean.Suggestion;
import com.TommasiniVerosimile.Dream.bean.UsedProduct;
import com.TommasiniVerosimile.Dream.modelDTO.FarmerDTO;
import com.TommasiniVerosimile.Dream.modelDTO.SuggestionDTO;
import com.TommasiniVerosimile.Dream.repository.FarmerRepository;
import com.TommasiniVerosimile.Dream.repository.SuggestionRepository;

@Transactional
@SpringBootTest
public class SuggestionControllerTest {

	@Autowired
	private SuggestionController suggestionController;
	@Autowired
	private FarmerRepository farmerRepo;
	@Autowired
	private SuggestionRepository suggestionRepo;
	
	@Test
	public void addSuggestionTest() {
		SuggestionDTO sugg=new SuggestionDTO();
		FarmerDTO farmer= new FarmerDTO(farmerRepo.findFarmerById(1));
		sugg.setText("someSuggestion");
		sugg.setUploadedBy(farmer);
		suggestionController.addSuggestion(sugg);
		List<Suggestion> allSugg=(List<Suggestion>)suggestionRepo.findAll();
		boolean check=false;
		for(Suggestion s : allSugg) {
			if(s.getText().equals("someSuggestion") && s.getUploadedBy().getId()==farmer.getId())
				check=true;
		}
		Assertions.assertTrue(check);
	}
	
	@Test
	public void getSuggestionsTest() {
		Farmer farmer=farmerRepo.findFarmerById(1);
		List<SuggestionDTO> suggZone=suggestionController.getSuggestionFilteredZone(farmer.getId());
		boolean check1=true;
		for(SuggestionDTO s:suggZone) {
			if(((s.getUploadedBy().getFarm().getGeographicalZone()).equals(farmer.getFarm().getGeographicalZone())));
			else
		        check1=false;
		}
		Assertions.assertTrue(check1);
		
		List<SuggestionDTO> suggProducts=suggestionController.getSuggestionFilteredUsedProducts(farmer.getId());
		
		for(SuggestionDTO s:suggProducts) {
			check1=false;
			Farmer uploadedBy= farmerRepo.findFarmerById(s.getUploadedBy().getId());
			for(UsedProduct u: farmer.getUsedProducts())
				for(UsedProduct up: uploadedBy.getUsedProducts()) {
					if(u.getName().equals(up.getName()))
						check1=true;
				}
			if(check1==false) break;
		}
		Assertions.assertTrue(check1);
		
		
	}
	
}
