package com.TommasiniVerosimile.Dream.controller;

import java.util.List;

import javax.transaction.Transactional;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.TommasiniVerosimile.Dream.bean.Farmer;
import com.TommasiniVerosimile.Dream.bean.ProductQuantity;
import com.TommasiniVerosimile.Dream.bean.UsedProduct;
import com.TommasiniVerosimile.Dream.modelDTO.MeteoForecastDTO;
import com.TommasiniVerosimile.Dream.modelDTO.ProductQuantityDTO;
import com.TommasiniVerosimile.Dream.modelDTO.UsedProductDTO;
import com.TommasiniVerosimile.Dream.repository.FarmerRepository;

@Transactional
@SpringBootTest
public class InformationControllerTest {

	@Autowired 
	private InformationController infoController;
	@Autowired
	private FarmerRepository farmerRepo;
	
	@Test
	public void getMeteoForecastTest() {
		List<MeteoForecastDTO> forecasts=infoController.getMeteoForecast("city1", "2022-01-31");
	    boolean check=true;
		for(MeteoForecastDTO m : forecasts) {
	    	if(!(m.getLocation().equals("city1")) || !(m.getDay().substring(0,10).equals("2022-01-31")))
	    			check=false;
	    }
		Assertions.assertTrue(check);
	}
	
	@Test
	public void updateUsedProductTest() {
		Integer idFarmer=1;
		UsedProductDTO prod= new UsedProductDTO();
		prod.setName("fertilizer1");
		infoController.updateUsedproducts(idFarmer, prod);
		Farmer farmer=farmerRepo.findFarmerById(idFarmer);
		List<UsedProduct> products=farmer.getUsedProducts();
		boolean check=false;
		for(UsedProduct u: products) {
			if(u.getName().equals(prod.getName()))
				check=true;
		}
		Assertions.assertTrue(check);
	}
	
	@Test
	public void deleteUsedProductTest() {
		Integer idFarmer=1;
		Farmer farmer=farmerRepo.findFarmerById(idFarmer);
		String productName=farmer.getUsedProducts().get(0).getName();
		infoController.deleteUsedProduct(idFarmer, productName);
		boolean check=true;
		for(UsedProduct u: farmer.getUsedProducts()) {
			if(u.getName()==productName)
				check=false;
		}
		Assertions.assertTrue(check);
	}
	
	@Test 
	public void addProductionForAFarmerTest() {
		Integer idFarmer=1;
		Farmer farmer=farmerRepo.findFarmerById(idFarmer);
		ProductQuantityDTO pq=new ProductQuantityDTO();
		pq.setProductName("rice");
		pq.setQuantity(40.0);
		infoController.addProductionForAFarmer(pq, idFarmer);
	    List<ProductQuantity> productions=farmer.getProductions();
	    boolean check=false;
	    for(ProductQuantity p: productions) {
	    	if(p.getProduct().getName().equals(pq.getProductName()) && p.getQuantity()==pq.getQuantity())
	        check=true;
	    }
	    Assertions.assertTrue(check);
	}
	
	@Test
	public void deleteProductForAFarmerTest() {
		Integer idFarmer=4;
		Farmer farmer=farmerRepo.findFarmerById(idFarmer);
		String productName=farmer.getProductions().get(0).getProduct().getName();
	    infoController.deleteProductForAFarmer(idFarmer, productName);
	    Farmer farmer2=farmerRepo.findFarmerById(idFarmer);
	    List<ProductQuantity> productions=farmer2.getProductions();
	    boolean check=true;
	    for(ProductQuantity p: productions) {
	    	if(p.getProduct().getName().equals(productName))
	    		check=false;
	    }
	    Assertions.assertTrue(check);
	}

}
