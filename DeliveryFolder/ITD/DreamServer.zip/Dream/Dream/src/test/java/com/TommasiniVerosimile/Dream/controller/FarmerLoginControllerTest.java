package com.TommasiniVerosimile.Dream.controller;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.TommasiniVerosimile.Dream.modelDTO.FarmDTO;
import com.TommasiniVerosimile.Dream.modelDTO.FarmerDTO;

@SpringBootTest
public class FarmerLoginControllerTest {

	@Autowired
	private FarmerLoginController farmerLoginController;
	
	@Test
	public void loginTest() {
		String email="AjitSharma@gmail.com";
		String password= "Ajitpw";
		FarmerDTO farmer= farmerLoginController.login(email, password);
		Assertions.assertNotNull(farmer);
		Assertions.assertEquals(farmer.getEmail(), email);
		Assertions.assertEquals(farmer.getPw(), password);
		
		String email2="nonExistentEmail";
		String password2="nonExistentPw";
		FarmerDTO farmer2= farmerLoginController.login(email2, password2);
	    Assertions.assertNull(farmer2);
	}
	
	@Test
	public void checkRegCredentialsTest() {
		String email="AjitSharma@gmail.com";
		Boolean check=farmerLoginController.checkRegCredentials(email);
		Assertions.assertFalse(check);
		String email2="nonPresentEmail";
		Boolean check2=farmerLoginController.checkRegCredentials(email2);
		Assertions.assertTrue(check2);
	}
	
	@Test
	public void registrationTest() {
		FarmerDTO farmer= new FarmerDTO();
		farmer.setEmail("someEmail");
		farmer.setName("someName");
		farmer.setSurname("someSurname");
		farmer.setPw("somePw");
		FarmDTO farm=new FarmDTO();
		farm.setName("farmName");
		farm.setCity("farmCity");
		farm.setGeographicalZone("farmZone");
		farm.setSize(1);
		farmer.setFarm(farm);
		farmerLoginController.registration(farmer);
		FarmerDTO farmerInserted = farmerLoginController.login("someEmail", "somePw");
		Assertions.assertEquals("someName", farmerInserted.getName());
		Assertions.assertEquals("someSurname", farmerInserted.getSurname());
		Assertions.assertEquals("farmName", farmerInserted.getFarm().getName());
		Assertions.assertEquals("farmCity", farmerInserted.getFarm().getCity());
		Assertions.assertEquals("farmZone", farmerInserted.getFarm().getGeographicalZone());
		Assertions.assertEquals(1, farmerInserted.getFarm().getSize());
		
	}
}
