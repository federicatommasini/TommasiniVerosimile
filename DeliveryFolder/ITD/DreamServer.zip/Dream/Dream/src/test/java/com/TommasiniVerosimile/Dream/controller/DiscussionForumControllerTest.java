package com.TommasiniVerosimile.Dream.controller;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.TommasiniVerosimile.Dream.modelDTO.DiscussionForumDTO;
import com.TommasiniVerosimile.Dream.modelDTO.ForumPostDTO;


@SpringBootTest
public class DiscussionForumControllerTest {

	@Autowired
	private DiscussionForumController discForumController;
	
	@Test
    public void discussionForumTest() {
		List<ForumPostDTO> posts=new ArrayList<ForumPostDTO>();
		DiscussionForumDTO forum1= new DiscussionForumDTO();
		forum1.setTopic("someTopic");
		forum1.setPosts(posts);
		discForumController.addDiscussionForum(1, forum1);
		List<DiscussionForumDTO> disc=discForumController.searchDiscussionByTopic("some");
		Boolean check = false;
		for (DiscussionForumDTO d:disc) {
			if (d.getTopic().equals(forum1.getTopic()));
				check = true;
		}
		Assertions.assertTrue(check);
		
	}
	
	@Test
	public void forumPostTest() {
		List <DiscussionForumDTO> disc = discForumController.searchDiscussionByTopic("facing bad weather");
		DiscussionForumDTO d = disc.get(0);
		ForumPostDTO post=new ForumPostDTO();
		post.setText("someText");
		discForumController.addForumPost(d.getId(), 1, post);
		List<DiscussionForumDTO> d2 = discForumController.searchDiscussionByTopic(d.getTopic());
		Boolean check = false;
		for (DiscussionForumDTO df: d2) {
			for (ForumPostDTO fp: df.getPosts()) {
				if (fp.getText().equals(post.getText()) && fp.getWrittenBy().getId() == 1 && df.getId() == d.getId()){
					check = true;
				}
			}
		}
		Assertions.assertTrue(check);
	}

    
    
}
