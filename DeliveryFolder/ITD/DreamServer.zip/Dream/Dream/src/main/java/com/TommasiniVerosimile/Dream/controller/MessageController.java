package com.TommasiniVerosimile.Dream.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.TommasiniVerosimile.Dream.modelDTO.MessageDTO;
import com.TommasiniVerosimile.Dream.service.MessageService;

@RestController
public class MessageController {

	@Autowired
	private MessageService messageService;
	
	@RequestMapping("/messages/{id}")
	public List<MessageDTO> getAllMessages(@PathVariable Integer id){
		return messageService.getAllMessages(id);
	}
	
	@RequestMapping("/setAnswered")
	public void setAnsweredMessage(@RequestBody MessageDTO msg) {
		messageService.setAnsweredMessage(msg.getId());
	}
	
	@RequestMapping(method=RequestMethod.POST, value="/messages/add")
	public void addMessage(@RequestBody MessageDTO message) {
		messageService.addMessage(message);
	}
}
