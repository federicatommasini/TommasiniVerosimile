package com.TommasiniVerosimile.Dream.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.TommasiniVerosimile.Dream.modelDTO.MeteoForecastDTO;
import com.TommasiniVerosimile.Dream.modelDTO.ProductQuantityDTO;
import com.TommasiniVerosimile.Dream.modelDTO.UsedProductDTO;
import com.TommasiniVerosimile.Dream.service.InformationService;

@RestController
public class InformationController {

	@Autowired
	private InformationService informationService;
	
	@RequestMapping("/meteoForecasts/{location}/{day}")
	public List<MeteoForecastDTO> getMeteoForecast(@PathVariable String location, @PathVariable String day){
		return informationService.getMeteoForecast(location,day);
	}
	
	@RequestMapping(method=RequestMethod.PUT, value="/usedProducts/add/{id}")
	public void updateUsedproducts(@PathVariable Integer id, @RequestBody UsedProductDTO usedProduct){
		informationService.updateUsedProduct(id,usedProduct.getName());
	}
	
	@RequestMapping(method=RequestMethod.DELETE, value="/usedProducts/delete/{id}/{name}")
	public void deleteUsedProduct(@PathVariable Integer id, @PathVariable String name){
		informationService.deleteUsedProduct(id, name);
	}
	
	@RequestMapping("/getUsedProducts/{id}")
	public List<UsedProductDTO> getUsedProductsByFarmer(@PathVariable Integer id) {
		return informationService.getUsedProductsByFarmer(id);
	}
	
	@RequestMapping("/getProductions/{id}")
	public List<ProductQuantityDTO> getAllProductionsbyFarmer(@PathVariable Integer id){
		return informationService.getAllProductionsByFarmer(id);
	}
	
	@RequestMapping(method=RequestMethod.POST, value="/productions/add/{id}")
	public void addProductionForAFarmer(@RequestBody ProductQuantityDTO production, @PathVariable Integer id){
		informationService.addProduction(production,id);
	}
	
	@RequestMapping(method=RequestMethod.DELETE, value="/productions/delete/{id}/{name}")
	public void deleteProductForAFarmer(@PathVariable Integer id, @PathVariable String name) {
		informationService.deleteProductionByFarmer(id,name);
	}
	
	
	
}
