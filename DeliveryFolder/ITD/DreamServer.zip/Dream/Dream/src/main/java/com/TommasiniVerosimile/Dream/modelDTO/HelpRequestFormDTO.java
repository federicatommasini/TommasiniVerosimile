package com.TommasiniVerosimile.Dream.modelDTO;

import com.TommasiniVerosimile.Dream.bean.HelpRequestForm;

public class HelpRequestFormDTO {

	private Integer id;
	private String problemDescription;
	private FarmerDTO askedBy;
	
	public HelpRequestFormDTO() {
		super();
	}
	
	public HelpRequestFormDTO(HelpRequestForm hrf) {
		id = hrf.getId();
		problemDescription = hrf.getProblemDescription();
		askedBy = new FarmerDTO(hrf.getAskedBy());
	}
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getProblemDescription() {
		return problemDescription;
	}
	public void setProblemDescription(String problemDescription) {
		this.problemDescription = problemDescription;
	}
	public FarmerDTO getAskedBy() {
		return askedBy;
	}
	public void setAskedBy(FarmerDTO askedBy) {
		this.askedBy = askedBy;
	}
	
	
}
