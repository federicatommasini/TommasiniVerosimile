package com.TommasiniVerosimile.Dream.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.TommasiniVerosimile.Dream.modelDTO.ForumPostDTO;

@Entity
@Table(name="ForumPost")
public class ForumPost {
 
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer id;
	
	private String text;
	
	@ManyToOne
	@JoinColumn(name="writtenBy")
	private Farmer writtenBy;
	
	@ManyToOne
	@JoinColumn(name="belongsTo")
	private DiscussionForum belongsTo;

	public ForumPost() {
		super();
	}

	public ForumPost(Integer id, String text, Farmer writtenBy, DiscussionForum belongsTo) {
		super();
		this.id = id;
		this.text = text;
		this.writtenBy = writtenBy;
		this.belongsTo = belongsTo;
	}
	
	public ForumPost(ForumPostDTO post) {
		id=post.getId();
		text=post.getText();
		
	}
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public Farmer getWrittenBy() {
		return writtenBy;
	}

	public void setWrittenBy(Farmer writtenBy) {
		this.writtenBy = writtenBy;
	}

	public DiscussionForum getBelongsTo() {
		return belongsTo;
	}

	public void setBelongsTo(DiscussionForum belongsTo) {
		this.belongsTo = belongsTo;
	}
	
	

}
