package com.TommasiniVerosimile.Dream.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.TommasiniVerosimile.Dream.bean.DiscussionForum;

public interface DiscussionForumRepository extends CrudRepository<DiscussionForum,Integer>{

	@Query("select d from DiscussionForum d where d.id= :i")
	public DiscussionForum searchById(@Param("i") Integer id);
	
	@Query("select d from DiscussionForum d where d.topic like :top")
	public List<DiscussionForum> findByTopic(@Param("top") String topic);
}