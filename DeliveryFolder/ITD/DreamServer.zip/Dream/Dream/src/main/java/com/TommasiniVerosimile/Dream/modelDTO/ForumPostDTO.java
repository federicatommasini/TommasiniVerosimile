package com.TommasiniVerosimile.Dream.modelDTO;

import com.TommasiniVerosimile.Dream.bean.ForumPost;

public class ForumPostDTO {

	private Integer id;
	private String text;
	private FarmerDTO writtenBy;
	
	public ForumPostDTO() {
		super();
	}
	
	public ForumPostDTO(ForumPost post) {
		id=post.getId();
		text=post.getText();
		writtenBy= new FarmerDTO(post.getWrittenBy()); 
	}
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	public FarmerDTO getWrittenBy() {
		return writtenBy;
	}
	public void setWrittenBy(FarmerDTO writtenBy) {
		this.writtenBy = writtenBy;
	}
	

}
