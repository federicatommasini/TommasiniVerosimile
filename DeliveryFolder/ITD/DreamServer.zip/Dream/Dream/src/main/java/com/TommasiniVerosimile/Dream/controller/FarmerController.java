package com.TommasiniVerosimile.Dream.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.TommasiniVerosimile.Dream.modelDTO.FarmerDTO;
import com.TommasiniVerosimile.Dream.service.FarmerService;

@RestController
public class FarmerController {

	@Autowired
	private FarmerService farmerService;
	
	@RequestMapping(method=RequestMethod.POST, value="/associateCondition/{id}")
	public void associateCondition(@RequestBody FarmerDTO farmer, @PathVariable Integer id){
		farmerService.associateSoilCondition(id);
		farmerService.associateMeteoCondition(id);
	}
}


