package com.TommasiniVerosimile.Dream.bean;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.TommasiniVerosimile.Dream.modelDTO.MessageDTO;

@Entity
@Table(name="Message")
public class Message {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer id;
	
	private String text;
	
	private Date time;
	
	private int answered;
	private int request;
	
	@ManyToOne
	@JoinColumn(name="sender")
	private Farmer sender;
	
	@ManyToOne
	@JoinColumn(name="receiver")
	private Farmer receiver;

	public Message() {
		super();
	}

	public Message(MessageDTO msg) {
		id = msg.getId();
		text = msg.getText();
		time = msg.getTime();
		answered=msg.getAnswered();
		request=msg.getRequest();
		
	}
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public Date getTime() {
		return time;
	}

	public void setTime(Date time) {
		this.time = time;
	}

	public Farmer getSender() {
		return sender;
	}

	public void setSender(Farmer sender) {
		this.sender = sender;
	}

	public Farmer getReceiver() {
		return receiver;
	}

	public void setReceiver(Farmer receiver) {
		this.receiver = receiver;
	}

	public int getAnswered() {
		return answered;
	}

	public void setAnswered(int answered) {
		this.answered = answered;
	}

	public int getRequest() {
		return request;
	}

	public void setRequest(int request) {
		this.request = request;
	}
	
	
}
