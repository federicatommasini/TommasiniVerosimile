package com.TommasiniVerosimile.Dream.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.TommasiniVerosimile.Dream.modelDTO.FarmerDTO;
import com.TommasiniVerosimile.Dream.service.FarmerLoginService;

@RestController
public class FarmerLoginController {

	@Autowired
	private FarmerLoginService farmerLoginService;
	
	@RequestMapping("/login/{email}/{password}")
	public FarmerDTO login(@PathVariable String email, @PathVariable String password){
		return farmerLoginService.login(email,password);
	}
	
	@RequestMapping("/checkRegCredentials/{email}")
	public Boolean checkRegCredentials(@PathVariable String email){
		return farmerLoginService.checkRegCredentials(email);
	}
	
	@RequestMapping(method=RequestMethod.POST, value="/registration")
	public FarmerDTO registration(@RequestBody FarmerDTO farmer){
		return farmerLoginService.registration(farmer);
	}

}
