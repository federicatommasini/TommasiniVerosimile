package com.TommasiniVerosimile.Dream.bean;


import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;


@Entity
@Table(name="UsedProduct")
public class UsedProduct {
 
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer id;
	
	private String name;
	
	@ManyToMany(fetch=FetchType.EAGER,mappedBy="usedProducts")
    private List<Farmer> farmers = new ArrayList<Farmer>();

	public UsedProduct() {
		super();
	}

	public UsedProduct(Integer id, String name, List<Farmer> farmers) {
		super();
		this.id = id;
		this.name = name;
		this.farmers = farmers;
	}
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<Farmer> getFarmers() {
		return farmers;
	}

	public void setFarmers(List<Farmer> farmers) {
		this.farmers = farmers;
	}
	
	
	
}
