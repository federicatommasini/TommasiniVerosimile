package com.TommasiniVerosimile.Dream.repository;

import org.springframework.data.repository.CrudRepository;

import com.TommasiniVerosimile.Dream.bean.Suggestion;

public interface SuggestionRepository extends CrudRepository<Suggestion,Integer>{

}
