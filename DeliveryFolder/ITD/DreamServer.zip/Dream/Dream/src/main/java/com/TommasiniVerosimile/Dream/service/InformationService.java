package com.TommasiniVerosimile.Dream.service;


import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.TommasiniVerosimile.Dream.bean.Farmer;
import com.TommasiniVerosimile.Dream.bean.MeteoForecast;
import com.TommasiniVerosimile.Dream.bean.Product;
import com.TommasiniVerosimile.Dream.bean.ProductQuantity;
import com.TommasiniVerosimile.Dream.bean.UsedProduct;
import com.TommasiniVerosimile.Dream.modelDTO.MeteoForecastDTO;
import com.TommasiniVerosimile.Dream.modelDTO.ProductQuantityDTO;
import com.TommasiniVerosimile.Dream.modelDTO.UsedProductDTO;
import com.TommasiniVerosimile.Dream.repository.UsedProductRepository;
import com.TommasiniVerosimile.Dream.repository.MeteoForecastRepository;
import com.TommasiniVerosimile.Dream.repository.ProductQuantityRepository;
import com.TommasiniVerosimile.Dream.repository.ProductRepository;
import com.TommasiniVerosimile.Dream.repository.FarmRepository;
import com.TommasiniVerosimile.Dream.repository.FarmerRepository;

@Transactional
@Service
public class InformationService {
	
	@Autowired
	public MeteoForecastRepository meteoForecastRepo;
	
	@Autowired
	public FarmRepository farmRepo;
	
	@Autowired
	public FarmerRepository farmerRepo;
	
	@Autowired
	public UsedProductRepository usedProductRepo;
	
	@Autowired
	public ProductQuantityRepository productQuantityRepo;
	
	@Autowired
	public ProductRepository productRepo;
	
	public List<MeteoForecastDTO> getMeteoForecast(String location, String date){
		try{SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		Calendar c=Calendar.getInstance();
		Date day=formatter.parse(date);
		c.setTime(day);
		c.add(Calendar.DATE, 1);
        Date day2=c.getTime();
        List<MeteoForecast> meteoForecast=meteoForecastRepo.findByLocationAndDate(location, day, day2);
		List<MeteoForecastDTO> meteoForecastDTO=new ArrayList<MeteoForecastDTO>();
		for(MeteoForecast m: meteoForecast) {
		 meteoForecastDTO.add(new MeteoForecastDTO(m));
		 }
		return meteoForecastDTO;}
		catch(Exception e) {return null;}
		
	}
	
	
	
	public void updateUsedProduct(Integer id, String name) {
		
		UsedProduct up= usedProductRepo.findByName(name);
		Farmer farmer=farmerRepo.findFarmerById(id);
		List<Farmer> farmers=new ArrayList<Farmer>();
		List<UsedProduct> upFarmer= farmer.getUsedProducts();
		
		if(up!=null){
			if(!upFarmer.contains(up)) {
				upFarmer.add(up);
				farmers=up.getFarmers();
				farmers.add(farmer);
				up.setFarmers(farmers);
				usedProductRepo.save(up);
				farmer.setUsedProducts(upFarmer);
				farmerRepo.save(farmer);
			}
		}else {
			UsedProduct usedProduct=new UsedProduct();
			usedProduct.setName(name);
			farmers.add(farmer);
			usedProduct.setFarmers(farmers);
			upFarmer.add(usedProduct);
			farmer.setUsedProducts(upFarmer);
		    usedProductRepo.save(usedProduct);
		    farmerRepo.save(farmer);
		 }		
	}

	public void deleteUsedProduct(Integer id, String name){
		UsedProduct up= usedProductRepo.findByName(name);
		Farmer farmer=farmerRepo.findFarmerById(id);
		List<UsedProduct> upFarmer= farmer.getUsedProducts();
		upFarmer.remove(up);
		farmer.setUsedProducts(upFarmer);
		farmerRepo.save(farmer);	
		List<Farmer> farmers=up.getFarmers();
		farmers.remove(farmer);
		usedProductRepo.save(up);
	}
	
	public List<Product> getAllProducts(Integer id){
		Farmer farmer=farmerRepo.findFarmerById(id);
		List<ProductQuantity> productions = farmer.getProductions();
		List<Product> products=new ArrayList<Product>();
		for(ProductQuantity q : productions) {
			products.add(q.getProduct());
		}
		return products;
	}

	public List<ProductQuantityDTO> getAllProductionsByFarmer(Integer id){
		Farmer farmer=farmerRepo.findFarmerById(id);
		List<ProductQuantity> productions= productQuantityRepo.searchByFarmer(farmer);
		List<ProductQuantityDTO> dtoQuant=new ArrayList<ProductQuantityDTO>();
		for(ProductQuantity p:productions) {
			dtoQuant.add(new ProductQuantityDTO(p));
		}
		return dtoQuant;
	}

	public void addProduction(ProductQuantityDTO productionDTO, Integer id){
		ProductQuantity production = new ProductQuantity(productionDTO); 
		Farmer farmer = farmerRepo.findFarmerById(id);
		Product p = productRepo.findByName(productionDTO.getProductName());
		if(p!=null) {
			production.setFarmer(farmer);
			production.setProduct(p);
			productQuantityRepo.save(production);
		}else {
			Product pr=new Product();
			pr.setName(productionDTO.getProductName());
			productRepo.save(pr);
			production.setFarmer(farmer);
			production.setProduct(pr);
			productQuantityRepo.save(production);
		}
		
		
	}

	public void deleteProductionByFarmer(Integer id, String name){
		Farmer farmer= farmerRepo.findFarmerById(id);
		Product product=productRepo.findByName(name);
		ProductQuantity production=productQuantityRepo.searchByFarmerAndProduct(farmer, product);	
		List<ProductQuantity> productions= farmer.getProductions();
		productions.remove(production);
		farmerRepo.save(farmer);
		productQuantityRepo.delete(production);	
	}
	
	
	public List<UsedProductDTO> getUsedProductsByFarmer(Integer id){
		Farmer farmer= farmerRepo.findFarmerById(id);
		List<UsedProduct> up= farmer.getUsedProducts();
		List<UsedProductDTO> upDTO=new ArrayList<UsedProductDTO>();
		for(UsedProduct p:up) {
			upDTO.add(new UsedProductDTO(p));
		}
		return upDTO;
	}
	

}
