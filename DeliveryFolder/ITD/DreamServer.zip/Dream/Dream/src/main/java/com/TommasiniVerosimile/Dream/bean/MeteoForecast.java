package com.TommasiniVerosimile.Dream.bean;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="MeteoForecast")
public class MeteoForecast {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer id;
	
	private Date day;
	
	private String location;
	
	private Double temperature;
	
	private Double humidity;
	
	private Double rainfalls;

	public MeteoForecast() {
		super();
	}

	public MeteoForecast(Integer id, Date day, String location, Double temperature, Double humidity, Double rainfalls) {
		super();
		this.id = id;
		this.day = day;
		this.location = location;
		this.temperature = temperature;
		this.humidity = humidity;
		this.rainfalls = rainfalls;
	}
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Date getDay() {
		return day;
	}

	public void setDay(Date day) {
		this.day = day;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public Double getTemperature() {
		return temperature;
	}

	public void setTemperature(Double temperature) {
		this.temperature = temperature;
	}

	public Double getHumidity() {
		return humidity;
	}

	public void setHumidity(Double humidity) {
		this.humidity = humidity;
	}

	public Double getRainfalls() {
		return rainfalls;
	}

	public void setRainfalls(Double rainfalls) {
		this.rainfalls = rainfalls;
	}
	
	

}
