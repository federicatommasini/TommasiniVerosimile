package com.TommasiniVerosimile.Dream.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.TommasiniVerosimile.Dream.modelDTO.HelpRequestFormDTO;
import com.TommasiniVerosimile.Dream.service.HelpRequestFormService;

@RestController
public class HelpRequestFormController {

	@Autowired
	private HelpRequestFormService helpRequestService;
	
	@RequestMapping(method=RequestMethod.POST, value="/helpRequestForms")
	public void addHelpRequestForm(@RequestBody HelpRequestFormDTO helpRequestForm){
		helpRequestService.addHelpRequestForm(helpRequestForm);
	}
}
