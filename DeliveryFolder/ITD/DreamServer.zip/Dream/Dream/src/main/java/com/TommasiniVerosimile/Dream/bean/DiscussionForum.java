package com.TommasiniVerosimile.Dream.bean;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.TommasiniVerosimile.Dream.modelDTO.DiscussionForumDTO;

@Entity
@Table(name="DiscussionForum")
public class DiscussionForum {
 
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer id;
	
	private String topic;
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name="createdBy")
	private Farmer createdBy;
	
	@OneToMany(fetch = FetchType.EAGER, mappedBy="belongsTo")
	private List<ForumPost> posts= new ArrayList<ForumPost>();

	public DiscussionForum() {
		super();
	}

	public DiscussionForum(Integer id, String topic, Farmer createdBy) {
		super();
		this.id = id;
		this.topic = topic;
		this.createdBy = createdBy;
	}
	
	public DiscussionForum(DiscussionForumDTO forum) {
		id=forum.getId();
		topic=forum.getTopic();
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getTopic() {
		return topic;
	}

	public void setTopic(String topic) {
		this.topic = topic;
	}

	public Farmer getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Farmer createdBy) {
		this.createdBy = createdBy;
	}

	public List<ForumPost> getPosts() {
		return posts;
	}

	public void setPosts(List<ForumPost> posts) {
		this.posts = posts;
	}
	
	
}