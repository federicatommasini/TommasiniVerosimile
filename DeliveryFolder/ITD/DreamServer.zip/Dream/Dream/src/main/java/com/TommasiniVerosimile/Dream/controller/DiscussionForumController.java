package com.TommasiniVerosimile.Dream.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.TommasiniVerosimile.Dream.modelDTO.DiscussionForumDTO;
import com.TommasiniVerosimile.Dream.modelDTO.ForumPostDTO;
import com.TommasiniVerosimile.Dream.service.DiscussionForumService;

@RestController
public class DiscussionForumController {

	@Autowired
	private DiscussionForumService discussionForumService;
	
	
	@RequestMapping(method=RequestMethod.POST, value="/discussionForums/{id}")
	public void addDiscussionForum(@PathVariable Integer id, @RequestBody DiscussionForumDTO discussionForum) {
		discussionForumService.addDiscussionForum(id, discussionForum);
	}
	
	@RequestMapping(method=RequestMethod.POST, value="/discussionForumPosts/{idForum}/{idFarmer}")
	public void addForumPost(@PathVariable Integer idForum, @PathVariable Integer idFarmer,@RequestBody ForumPostDTO forumPost) {
		discussionForumService.addForumPost(idFarmer,idForum, forumPost);
	}
	
	@RequestMapping("/searchDiscussionForums/{topic}")
	public List<DiscussionForumDTO> searchDiscussionByTopic(@PathVariable String topic){
		return discussionForumService.searchDiscussionByTopic(topic);
	}
}
