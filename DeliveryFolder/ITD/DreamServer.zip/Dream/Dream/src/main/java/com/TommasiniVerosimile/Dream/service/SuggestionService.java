package com.TommasiniVerosimile.Dream.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.TommasiniVerosimile.Dream.bean.Suggestion;
import com.TommasiniVerosimile.Dream.bean.UsedProduct;
import com.TommasiniVerosimile.Dream.modelDTO.SuggestionDTO;

import com.TommasiniVerosimile.Dream.bean.Farm;
import com.TommasiniVerosimile.Dream.bean.Farmer;
import com.TommasiniVerosimile.Dream.repository.FarmerRepository;
import com.TommasiniVerosimile.Dream.repository.SuggestionRepository;


@Service
public class SuggestionService {
	
	
	@Autowired
	public SuggestionRepository suggestionRepo;
	
	@Autowired
	public FarmerRepository farmerRepo;
	
	public void addSuggestion(SuggestionDTO suggestionDTO) {
		Suggestion suggestion= new Suggestion(suggestionDTO);
		Farmer farmer = farmerRepo.findFarmerById(suggestionDTO.getUploadedBy().getId());
		suggestion.setUploadedBy(farmer);
		suggestionRepo.save(suggestion);
	}
	
	public List<SuggestionDTO> getSuggestionsFilteredByZone(Integer id){
		
		Farmer farmer=farmerRepo.findFarmerById(id);
		
		List<Suggestion> filteredSuggestions=new ArrayList<Suggestion>();
		
		Farm farm= farmer.getFarm();
		String geographicalZone=farm.getGeographicalZone();
		
		List<Farmer> farmersZone=farmerRepo.findByZone(geographicalZone);
		
		for(Farmer f: farmersZone) {
			List<Suggestion> sugg= f.getSuggestions();
			filteredSuggestions.addAll(sugg);
		}
		
		List<SuggestionDTO> dtoSugg=new ArrayList<SuggestionDTO>();
		for(Suggestion s: filteredSuggestions) {
			dtoSugg.add(new SuggestionDTO(s));
		}
		
		return dtoSugg;
	}
	
	public List<SuggestionDTO> getSuggestionsFilteredByUsedProducts(Integer id){
		
		Farmer farmer=farmerRepo.findFarmerById(id);
		
		List<Suggestion> filteredSuggestions=new ArrayList<Suggestion>();
		List<Farmer> similarFarmers=new ArrayList<Farmer>();
		
		List<UsedProduct> usedProducts=farmer.getUsedProducts();
		
		for(UsedProduct p : usedProducts){
			similarFarmers.addAll(farmerRepo.findByUsedProducts(p));
		}
		
		for(Farmer f: similarFarmers) {
			List<Suggestion> sugg= f.getSuggestions();
			for(Suggestion s:sugg) {
				if(!filteredSuggestions.contains(s))
			        filteredSuggestions.add(s);
			}
		}
		
		List<SuggestionDTO> dtoSugg=new ArrayList<SuggestionDTO>();
		for(Suggestion s: filteredSuggestions) {
			dtoSugg.add(new SuggestionDTO(s));
		}
		
		return dtoSugg;
	}
	
	public List<SuggestionDTO> getSuggestionsFIlteredByEnvCondition(Integer id){
		
		Farmer farmer=farmerRepo.findFarmerById(id);
		
		List<Suggestion> filteredSuggestions=new ArrayList<Suggestion>();
		
		String soilCond= farmer.getFarm().getSoilCondition();
		String meteoCond= farmer.getFarm().getMeteoCondition();
		
		List<Farmer> similarSoilCondFarmers= new ArrayList<Farmer>();
		List<Farmer> similarMeteoCondFarmers= new ArrayList<Farmer>();
		List<Farmer> similarEnvCondFarmers= new ArrayList<Farmer>();
		
		switch(soilCond) {
		case "VERYGOOD": 
			similarSoilCondFarmers.addAll(farmerRepo.findBySoilCondition("VERYGOOD", "GOOD"));
		    break;
		case "GOOD":
			similarSoilCondFarmers.addAll(farmerRepo.findBySoilCondition("VERYGOOD", "GOOD", "NORMAL"));
		    break;
		case "NORMAL":
			similarSoilCondFarmers.addAll(farmerRepo.findBySoilCondition("GOOD", "NORMAL", "BAD"));
		    break;
		case "BAD":
			similarSoilCondFarmers.addAll(farmerRepo.findBySoilCondition("NORMAL", "BAD", "VERYBAD"));
		    break;
		case "VERYBAD":
			similarSoilCondFarmers.addAll(farmerRepo.findBySoilCondition("BAD", "VERYBAD"));
		    break;
		}
		
		switch(meteoCond) {
		case "VERYGOOD": 
			similarMeteoCondFarmers.addAll(farmerRepo.findByMeteoCondition("VERYGOOD", "GOOD"));
		    break;
		case "GOOD":
			similarMeteoCondFarmers.addAll(farmerRepo.findByMeteoCondition("VERYGOOD", "GOOD", "NORMAL"));
		    break;
		case "NORMAL":
			similarMeteoCondFarmers.addAll(farmerRepo.findByMeteoCondition("GOOD", "NORMAL", "BAD"));
		    break;
		case "BAD":
			similarMeteoCondFarmers.addAll(farmerRepo.findByMeteoCondition("NORMAL", "BAD", "VERYBAD"));
		    break;
		case "VERYBAD":
			similarMeteoCondFarmers.addAll(farmerRepo.findByMeteoCondition("BAD", "VERYBAD"));
		    break;
		}
		
		for(Farmer f : similarSoilCondFarmers) {
			if(similarMeteoCondFarmers.contains(f))
				similarEnvCondFarmers.add(f);
		}
		
		for(Farmer f: similarEnvCondFarmers) {
			List<Suggestion> sugg= f.getSuggestions();
			filteredSuggestions.addAll(sugg);
		}
		
		List<SuggestionDTO> dtoSugg=new ArrayList<SuggestionDTO>();
		for(Suggestion s: filteredSuggestions) {
			dtoSugg.add(new SuggestionDTO(s));
		}
		
		return dtoSugg;
	}
}
