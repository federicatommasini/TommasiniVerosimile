package com.TommasiniVerosimile.Dream.service;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.TommasiniVerosimile.Dream.bean.Farm;
import com.TommasiniVerosimile.Dream.bean.Farmer;
import com.TommasiniVerosimile.Dream.bean.MeteoForecast;
import com.TommasiniVerosimile.Dream.bean.SoilMeasurement;
import com.TommasiniVerosimile.Dream.repository.FarmRepository;
import com.TommasiniVerosimile.Dream.repository.FarmerRepository;
import com.TommasiniVerosimile.Dream.repository.MeteoForecastRepository;
import com.TommasiniVerosimile.Dream.repository.SoilMeasurementRepository;

@Service
public class FarmerService {
	
	
	@Autowired
	public FarmerRepository farmerRepo;
	
	@Autowired
	public SoilMeasurementRepository soilMeasRepo;
	
	@Autowired
	public MeteoForecastRepository meteoForRepo;
	
	@Autowired
	public FarmRepository farmRepo;

	public void associateSoilCondition(Integer id){
		Farmer farmer = farmerRepo.findFarmerById(id);	
		Farm farm=farmer.getFarm();
		Date today=new Date();
		Calendar cal = new GregorianCalendar();
		cal.setTime(today);
		cal.add(Calendar.DAY_OF_MONTH, -30);
		Date today30 = cal.getTime();
		List<SoilMeasurement> lastMonthSoilMeasurements= soilMeasRepo.findByDayAndLocationLastMonth(today,today30,farm.getCity());
		
		Double averageHumidity=0.0;
		for(SoilMeasurement s : lastMonthSoilMeasurements){
			averageHumidity += s.getHumidity();
		}
		averageHumidity= averageHumidity/(lastMonthSoilMeasurements.size());
		
		if(averageHumidity>=65 && averageHumidity<=75){
			farm.setSoilCondition( "VERYGOOD");
		}else if((averageHumidity>=60 && averageHumidity<65) || (averageHumidity>=75 && averageHumidity<=80)) {
			farm.setSoilCondition( "GOOD");
		}else if((averageHumidity>=55 && averageHumidity<60) || (averageHumidity>80 && averageHumidity<=85)) {
			farm.setSoilCondition( "NORMAL");
		}else if((averageHumidity>=50 && averageHumidity<55) || (averageHumidity>85 && averageHumidity<=90)) {
			farm.setSoilCondition( "BAD");
		}else {
			farm.setSoilCondition( "VERYBAD");
		}
		
		farmRepo.save(farm);
	}
	
	public void associateMeteoCondition(Integer id){
		Farmer farmer = farmerRepo.findFarmerById(id);	
		Farm farm=farmer.getFarm();
		Date today=new Date();
		Calendar cal = new GregorianCalendar();
		cal.setTime(today);
		cal.add(Calendar.DAY_OF_MONTH, -30);
		Date today30 = cal.getTime();
		List<MeteoForecast> lastMonthMeteoForecasts= meteoForRepo.findByDayAndLocationLastMonth(today,today30 ,farm.getCity());
		
		int penaltyPoints=0;
		Double averageTemperature=0.0;
		Double averageHumidity=0.0;
		Double sumRainfalls=0.0;
		for(MeteoForecast m : lastMonthMeteoForecasts){
			averageTemperature+=m.getTemperature();
			averageHumidity+=m.getHumidity();
			sumRainfalls+=m.getRainfalls();
		}
		averageTemperature=averageTemperature/(lastMonthMeteoForecasts.size());
		averageHumidity=averageHumidity/(lastMonthMeteoForecasts.size());
		
		if(averageTemperature>=26 && averageTemperature<=31){
			penaltyPoints+=0;
		}else if((averageTemperature>=23 && averageTemperature<26) || (averageTemperature>31 && averageTemperature<=34)) {
			penaltyPoints+=1;
		}else if((averageTemperature>=20 && averageTemperature<23) || (averageTemperature>34 && averageTemperature<=37)) {
			penaltyPoints+=2;
		}else if((averageTemperature>=17 && averageTemperature<20) || (averageTemperature>37 && averageTemperature<=40)) {
			penaltyPoints+=3;
		}else{
			penaltyPoints+=4;
		}
		
		if(averageHumidity>=35 && averageHumidity<=45){
			penaltyPoints+=0;
		}else if((averageHumidity>=30 && averageHumidity<35) || (averageHumidity>45 && averageHumidity<=50)) {
			penaltyPoints+=1;
		}else if((averageHumidity>=25 && averageHumidity<30) || (averageHumidity>50 && averageHumidity<=55)) {
			penaltyPoints+=2;
		}else if((averageHumidity>=20 && averageHumidity<25) || (averageHumidity>55 && averageHumidity<=60)) {
			penaltyPoints+=3;
		}else{
			penaltyPoints+=4;
		}
		
		if(sumRainfalls>=85 && sumRainfalls<=90) {
			penaltyPoints+=0;
		}else if((sumRainfalls>=81 && sumRainfalls<85) || (sumRainfalls>90 && sumRainfalls<=94)) {
			penaltyPoints+=1;
		}else if((sumRainfalls>=77 && sumRainfalls<81) || (sumRainfalls>94 && sumRainfalls<=98)) {
			penaltyPoints+=2;
		}else if((sumRainfalls>=73 && sumRainfalls<77) || (sumRainfalls>98 && sumRainfalls<=102)) {
			penaltyPoints+=3;
		}else {
			penaltyPoints+=4;
		}
		
	   if(penaltyPoints==0){
		   farm.setMeteoCondition( "VERYGOOD");
	   }else if(penaltyPoints>0 && penaltyPoints<=2){
		   farm.setMeteoCondition( "GOOD");
	   }else if(penaltyPoints>2 && penaltyPoints<=5){
		   farm.setMeteoCondition( "NORMAL");
	   }else if(penaltyPoints>5 && penaltyPoints<=8){
		   farm.setMeteoCondition( "BAD");
	   }else{
		   farm.setMeteoCondition( "VERYBAD");
	   }
	   
	   farmRepo.save(farm);
	}
}