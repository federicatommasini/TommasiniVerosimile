package com.TommasiniVerosimile.Dream.modelDTO;

import com.TommasiniVerosimile.Dream.bean.Suggestion;

public class SuggestionDTO {

	private Integer id;
	private String text;
	private FarmerDTO uploadedBy;
	
	public SuggestionDTO() {
		super();
	}
	
	public SuggestionDTO(Suggestion sg){
		id = sg.getId();
		text = sg.getText();
		uploadedBy = new FarmerDTO(sg.getUploadedBy());
	}
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	public FarmerDTO getUploadedBy() {
		return uploadedBy;
	}
	public void setUploadedBy(FarmerDTO uploadedBy) {
		this.uploadedBy = uploadedBy;
	}
	
	
}
