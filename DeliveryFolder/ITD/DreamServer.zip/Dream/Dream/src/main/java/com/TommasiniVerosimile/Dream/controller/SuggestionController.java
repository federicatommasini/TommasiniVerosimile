package com.TommasiniVerosimile.Dream.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.TommasiniVerosimile.Dream.modelDTO.SuggestionDTO;
import com.TommasiniVerosimile.Dream.service.SuggestionService;

@RestController
public class SuggestionController {

	@Autowired
	private SuggestionService suggestionService;
	
	@RequestMapping(method=RequestMethod.POST, value="/suggestions")
	public void addSuggestion(@RequestBody SuggestionDTO suggestion) {
		suggestionService.addSuggestion(suggestion);
	}
	
	@RequestMapping("/suggestionsZone/{id}")
	public List<SuggestionDTO> getSuggestionFilteredZone(@PathVariable Integer id){
		return suggestionService.getSuggestionsFilteredByZone(id);
	}
	
	@RequestMapping("/suggestionsUsedProducts/{id}")
	public List<SuggestionDTO> getSuggestionFilteredUsedProducts(@PathVariable Integer id){
		return suggestionService.getSuggestionsFilteredByUsedProducts(id);
	}
	
	@RequestMapping("/suggestionsEnvCondition/{id}")
	public List<SuggestionDTO> getSuggestionFilteredEnvCondition(@PathVariable Integer id){
		return suggestionService.getSuggestionsFIlteredByEnvCondition(id);
	}
}
