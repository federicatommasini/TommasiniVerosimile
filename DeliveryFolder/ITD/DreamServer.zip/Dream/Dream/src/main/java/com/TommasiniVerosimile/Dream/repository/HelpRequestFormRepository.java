package com.TommasiniVerosimile.Dream.repository;

import org.springframework.data.repository.CrudRepository;

import com.TommasiniVerosimile.Dream.bean.HelpRequestForm;

public interface HelpRequestFormRepository extends CrudRepository<HelpRequestForm,Integer>{

}