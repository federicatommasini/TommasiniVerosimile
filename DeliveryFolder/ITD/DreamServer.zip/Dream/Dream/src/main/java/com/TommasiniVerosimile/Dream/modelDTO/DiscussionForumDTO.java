package com.TommasiniVerosimile.Dream.modelDTO;

import java.util.ArrayList;
import java.util.List;

import com.TommasiniVerosimile.Dream.bean.DiscussionForum;
import com.TommasiniVerosimile.Dream.bean.ForumPost;

public class DiscussionForumDTO {

	private Integer id;
	private String topic;
	private FarmerDTO createdBy;
	private List<ForumPostDTO> posts;
	
	public DiscussionForumDTO() {
		super();
	}
	
	public DiscussionForumDTO(DiscussionForum forum) {
		id=forum.getId();
		topic=forum.getTopic();
		createdBy=new FarmerDTO(forum.getCreatedBy());
		List<ForumPostDTO> p= new ArrayList<ForumPostDTO>();
		for(ForumPost pos : forum.getPosts()) {
			p.add(new ForumPostDTO(pos));
		}
		posts=p;
	}
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getTopic() {
		return topic;
	}
	public void setTopic(String topic) {
		this.topic = topic;
	}
	public FarmerDTO getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(FarmerDTO createdBy) {
		this.createdBy = createdBy;
	}
	public List<ForumPostDTO> getPosts() {
		return posts;
	}
	public void setPosts(List<ForumPostDTO> posts) {
		this.posts = posts;
	}
	
	
}
