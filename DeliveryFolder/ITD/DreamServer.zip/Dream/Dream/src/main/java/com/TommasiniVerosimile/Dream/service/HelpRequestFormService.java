package com.TommasiniVerosimile.Dream.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.TommasiniVerosimile.Dream.bean.HelpRequestForm;
import com.TommasiniVerosimile.Dream.bean.Message;
import com.TommasiniVerosimile.Dream.modelDTO.HelpRequestFormDTO;
import com.TommasiniVerosimile.Dream.modelDTO.MessageDTO;
import com.TommasiniVerosimile.Dream.repository.FarmerRepository;
import com.TommasiniVerosimile.Dream.repository.HelpRequestFormRepository;
import com.TommasiniVerosimile.Dream.bean.Farmer;

@Service
public class HelpRequestFormService {

	@Autowired
	public HelpRequestFormRepository helpRequestFormRepo;

	@Autowired
	public FarmerRepository farmerRepo;

	@Autowired
	private MessageService messageService;

	public void addHelpRequestForm(HelpRequestFormDTO helpRequestFormDTO) {
		HelpRequestForm helpRequestForm = new HelpRequestForm(helpRequestFormDTO);
		Farmer farmer = farmerRepo.findFarmerById(helpRequestFormDTO.getAskedBy().getId());
		helpRequestForm.setAskedBy(farmer);
		helpRequestFormRepo.save(helpRequestForm);
		findRightFarmer(helpRequestForm);
	}

	public void findRightFarmer(HelpRequestForm helpRequestForm) {
		Farmer asker = helpRequestForm.getAskedBy();
		List<Farmer> goodFarmers = farmerRepo.findByStatus("GOOD");

		String soilCond = asker.getFarm().getSoilCondition();
		String meteoCond = asker.getFarm().getMeteoCondition();

		List<Farmer> similarSoilCondFarmers = new ArrayList<Farmer>();
		List<Farmer> similarMeteoCondFarmers = new ArrayList<Farmer>();
		List<Farmer> similarEnvCondFarmers = new ArrayList<Farmer>();
		List<Farmer> possibleRespondents = new ArrayList<Farmer>();

		switch (soilCond) {
		case "VERYGOOD":
			similarSoilCondFarmers.addAll(farmerRepo.findBySoilCondition("VERYGOOD", "GOOD"));
			break;
		case "GOOD":
			similarSoilCondFarmers.addAll(farmerRepo.findBySoilCondition("VERYGOOD", "GOOD", "NORMAL"));
			break;
		case "NORMAL":
			similarSoilCondFarmers.addAll(farmerRepo.findBySoilCondition("GOOD", "NORMAL", "BAD"));
			break;
		case "BAD":
			similarSoilCondFarmers.addAll(farmerRepo.findBySoilCondition("NORMAL", "BAD", "VERYBAD"));
			break;
		case "VERYBAD":
			similarSoilCondFarmers.addAll(farmerRepo.findBySoilCondition("BAD", "VERYBAD"));
			break;
		}

		switch (meteoCond) {
		case "VERYGOOD":
			similarMeteoCondFarmers.addAll(farmerRepo.findByMeteoCondition("VERYGOOD", "GOOD"));
			break;
		case "GOOD":
			similarMeteoCondFarmers.addAll(farmerRepo.findByMeteoCondition("VERYGOOD", "GOOD", "NORMAL"));
			break;
		case "NORMAL":
			similarMeteoCondFarmers.addAll(farmerRepo.findByMeteoCondition("GOOD", "NORMAL", "BAD"));
			break;
		case "BAD":
			similarMeteoCondFarmers.addAll(farmerRepo.findByMeteoCondition("NORMAL", "BAD", "VERYBAD"));
			break;
		case "VERYBAD":
			similarMeteoCondFarmers.addAll(farmerRepo.findByMeteoCondition("BAD", "VERYBAD"));
			break;
		}

		for (Farmer f : similarSoilCondFarmers) {
			if (similarMeteoCondFarmers.contains(f) )
				similarEnvCondFarmers.add(f);
		}

		for (Farmer f : goodFarmers) {
			if (similarEnvCondFarmers.contains(f) && f.getId()!=asker.getId())
				possibleRespondents.add(f);
		}
		Farmer chosenRespondent = null;
		if (possibleRespondents.size() != 0) {
			int n = (int) Math.random() * (possibleRespondents.size());
			chosenRespondent = possibleRespondents.get(n);
		} else if (goodFarmers.size() != 0) {
			int n = (int) Math.random() * (goodFarmers.size());
			chosenRespondent = goodFarmers.get(n);
		} else if (similarEnvCondFarmers.size() != 0) {
			int n = (int) Math.random() * (similarEnvCondFarmers.size());
			chosenRespondent = similarEnvCondFarmers.get(n);
		}
		if (chosenRespondent != null) {
			Message message = new Message();
			message.setReceiver(chosenRespondent);
			message.setSender(asker);
			message.setText(helpRequestForm.getProblemDescription());
			message.setRequest(1);
			MessageDTO messageDTO = new MessageDTO(message);
			messageService.addMessage(messageDTO);
		}

	}

}
