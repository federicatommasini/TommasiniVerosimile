package com.TommasiniVerosimile.Dream.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.TommasiniVerosimile.Dream.bean.Farmer;
import com.TommasiniVerosimile.Dream.bean.Message;
import com.TommasiniVerosimile.Dream.modelDTO.MessageDTO;
import com.TommasiniVerosimile.Dream.repository.FarmerRepository;
import com.TommasiniVerosimile.Dream.repository.MessageRepository;

@Service
public class MessageService {

	@Autowired
	public MessageRepository messageRepo;

	@Autowired
	public FarmerRepository farmerRepo;

	public void addMessage(MessageDTO messageDTO) {
		Message message = new Message(messageDTO);
		Farmer sender = farmerRepo.findFarmerById(messageDTO.getSender().getId());
		Farmer receiver = farmerRepo.findFarmerById(messageDTO.getReceiver().getId());
		message.setTime(new Date());
		message.setSender(sender);
		message.setReceiver(receiver);
		messageRepo.save(message);
	}

	public List<MessageDTO> getAllMessages(Integer id) {
		Farmer farmer = farmerRepo.findFarmerById(id);
		List<Message> messages = new ArrayList<>();
		messageRepo.findByFarmer(farmer).forEach(messages::add);
		List<MessageDTO> dtoMessages = new ArrayList<MessageDTO>();
		for (Message m : messages) {
			dtoMessages.add(new MessageDTO(m));
		}
		return dtoMessages;
	}

	public void setAnsweredMessage(Integer id) {
	     Message message=messageRepo.findMessageById(id);
	     message.setAnswered(1);
	     messageRepo.save(message);
	}

}
