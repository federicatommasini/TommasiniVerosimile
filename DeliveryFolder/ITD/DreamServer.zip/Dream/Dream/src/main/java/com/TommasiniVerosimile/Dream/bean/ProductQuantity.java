package com.TommasiniVerosimile.Dream.bean;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.TommasiniVerosimile.Dream.modelDTO.ProductQuantityDTO;

@Entity
@Table(name="ProductQuantity")
public class ProductQuantity {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer id;
	
	@ManyToOne(cascade=CascadeType.PERSIST)
	@JoinColumn(name="product")
	private Product product;
	
	@ManyToOne(cascade=CascadeType.PERSIST)
	@JoinColumn(name="farmer")
	private Farmer farmer;
	
	private Double quantity;

	public ProductQuantity() {
		super();
	}

	public ProductQuantity(Integer id, Product product, Farmer farmer, Double quantity) {
		super();
		this.id = id;
		this.product = product;
		this.farmer = farmer;
		this.quantity = quantity;
	}
	
	public ProductQuantity(ProductQuantityDTO pq) {
		id = pq.getId();
		quantity = pq.getQuantity();
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public Farmer getFarmer() {
		return farmer;
	}

	public void setFarmer(Farmer farmer) {
		this.farmer = farmer;
	}

	public Double getQuantity() {
		return quantity;
	}

	public void setQuantity(Double quantity) {
		this.quantity = quantity;
	}
	
	

}
