package com.TommasiniVerosimile.Dream.repository;

import org.springframework.data.repository.CrudRepository;

import com.TommasiniVerosimile.Dream.bean.Farm;

public interface FarmRepository extends CrudRepository<Farm,Integer>{

}