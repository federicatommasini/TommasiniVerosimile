package com.TommasiniVerosimile.Dream.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.TommasiniVerosimile.Dream.bean.MeteoForecast;

public interface MeteoForecastRepository extends CrudRepository<MeteoForecast,Integer>{

	@Query("select m from MeteoForecast m where m.location = :c and (m.day between :d and :d2)")
	public List<MeteoForecast> findByLocationAndDate(@Param("c") String city, @Param("d") Date day, @Param("d2") Date day2);
	
	@Query("select m from MeteoForecast m where (m.day between :d2 and :d) and m.location= :l")
	public List<MeteoForecast> findByDayAndLocationLastMonth(@Param("d") Date day, @Param("d2") Date day2,  @Param("l") String location);
    
}
