package com.TommasiniVerosimile.Dream.config;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;
import javax.transaction.Transactional;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


import com.TommasiniVerosimile.Dream.bean.Farm;
import com.TommasiniVerosimile.Dream.bean.Farmer;
import com.TommasiniVerosimile.Dream.bean.Message;
import com.TommasiniVerosimile.Dream.bean.MeteoForecast;
import com.TommasiniVerosimile.Dream.bean.SoilMeasurement;
import com.TommasiniVerosimile.Dream.modelDTO.DiscussionForumDTO;
import com.TommasiniVerosimile.Dream.modelDTO.FarmerDTO;
import com.TommasiniVerosimile.Dream.modelDTO.ForumPostDTO;
import com.TommasiniVerosimile.Dream.modelDTO.HelpRequestFormDTO;
import com.TommasiniVerosimile.Dream.modelDTO.ProductQuantityDTO;
import com.TommasiniVerosimile.Dream.modelDTO.SuggestionDTO;
import com.TommasiniVerosimile.Dream.repository.FarmRepository;
import com.TommasiniVerosimile.Dream.repository.FarmerRepository;
import com.TommasiniVerosimile.Dream.repository.MessageRepository;
import com.TommasiniVerosimile.Dream.repository.MeteoForecastRepository;
import com.TommasiniVerosimile.Dream.repository.SoilMeasurementRepository;
import com.TommasiniVerosimile.Dream.service.DiscussionForumService;
import com.TommasiniVerosimile.Dream.service.FarmerService;
import com.TommasiniVerosimile.Dream.service.HelpRequestFormService;
import com.TommasiniVerosimile.Dream.service.InformationService;
import com.TommasiniVerosimile.Dream.service.SuggestionService;


@Component
public class DBPopulation {

	private static final Log LOG = LogFactory.getLog("ContextLoaderListener");

	@Autowired
	private MeteoForecastRepository meteoRepo;
	@Autowired
	private SoilMeasurementRepository soilRepo;
	@Autowired
	private FarmRepository farmRepo;
	@Autowired
	private FarmerRepository farmerRepo;
	@Autowired
	private MessageRepository messageRepo;	
	@Autowired 
	private HelpRequestFormService helpRequestsService;
	@Autowired
	private InformationService infoService;
	@Autowired
	private SuggestionService suggestionService;
	@Autowired
	private DiscussionForumService discussionService;
	@Autowired
	private FarmerService farmerService;
	
	@Transactional
	@PostConstruct
	 public void dbInitializer() {
		
		if(((List<Farmer>)farmerRepo.findAll()).size()==0) {
		
		LOG.info("Farmer table... adding new data");
		String[] names= {"Ajit", "Arihant", "Chaturanan", "Gaurish", "Harilal", "Kartik", "Markandeya"};
		String[] surnames= {"Sharma","Chandler", "Engineer", "Subramani", "Chandrasekar", "Aroulmoji", "Srivastava"};
		String[] farmNames= {"SunnyFarm", "WonderFarm", "BioFarm", "HarverstFarm", "GreenFarm", "RainbowFarm", "HappyFarm"};
		String[] cityNames= {"Adilabad", "Hyderabad", "Bhainsa", "Miyapur", "Sangareddy","Warangal", "Kurnool"};
		String[] zoneNames= {"Adilabad", "Hyderabad", "Adilabad", "Hyderabad", "Medak", "Warangal", "Mahbubnagar"};
		for(int i=0; i<7; i++) {
			Farmer farmer=new Farmer();
			farmer.setName(names[i]);
			farmer.setSurname(surnames[i]);
			farmer.setEmail(names[i]+surnames[i]+"@gmail.com");
			farmer.setPw(names[i]+"pw");
			if(i<3) farmer.setStatus("GOOD");
			else if(i<6) farmer.setStatus("BAD");
			else farmer.setStatus("NORMAL");
			Farm farm=new Farm();
			farm.setName(farmNames[i]);
			farm.setCity(cityNames[i]);
			farm.setMeteoCondition("NORMAL");
			farm.setSoilCondition("NORMAL");
			farm.setGeographicalZone(zoneNames[i]);
			farm.setSize((int)(Math.random()*950+50));
			farmer.setFarm(farm);
			farm.setFarmer(farmer);
			
			farmerRepo.save(farmer);
		}
		
		 LOG.info("MeteoForecast table... adding new data");
		 List<String> possibleLocations=((List<Farm>)farmRepo.findAll()).stream().map(farm->farm.getCity()).collect(Collectors.toList());
		 for(String location: possibleLocations) {
			 for(int i=-30; i<15; i++) {
				 for(int j=0; j<24; j++) {
				 MeteoForecast m=new MeteoForecast();
				 m.setTemperature(Math.round((Math.random()*28+12)*100.0)/100.0);
				 m.setRainfalls(Math.round((Math.random()*2)*100.0)/100.0);
				 m.setHumidity(Math.round((Math.random()*40+20)*100.0)/100.0);
		         m.setLocation(location);
		         SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		         SimpleDateFormat formatter2 = new SimpleDateFormat("yyyy-MM-dd HH:mm");
		 		 Calendar c=Calendar.getInstance();
		 		 Date today= new Date();
		 		 c.setTime(today);
	     		 c.add(Calendar.DATE, +i);
	     		 today=c.getTime();
		 		 String todayString= formatter.format(today);
		 		 try{
		 			 Date day1=formatter.parse(todayString);
		 			 String s=formatter.format(day1);
		 			 if(j<10) s=s+" 0"+j+":00";
		 			 else s=s+" "+j+":00";
		           	 Date day=formatter2.parse(s);
		        	 m.setDay(day);
		         } catch(Exception e) {
		        	 System.out.println(e.getStackTrace());
		         }
		         
		         meteoRepo.save(m);
				 } 
		   }
		 }
		
		 LOG.info("SoilMeasurement table... adding new data");
		 for(String location: possibleLocations) {
			 for(int i=0; i<30; i++) {
				 for(int j=0; j<24; j++) {
					 SoilMeasurement s=new SoilMeasurement();
					 s.setHumidity(Math.round((Math.random()*40+50)*100.0)/100.0);
			         s.setLocation(location);
			         SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
			         SimpleDateFormat formatter2 = new SimpleDateFormat("yyyy-MM-dd HH:mm");
			 		 Calendar c=Calendar.getInstance();
			 		 Date today= new Date();
			 		 c.setTime(today);
		     		 c.add(Calendar.DATE, -i);
		     		 today=c.getTime();
			 		 String todayString= formatter.format(today);
			 		 try{
			 			 Date day1=formatter.parse(todayString);
			 			 String st=formatter.format(day1);
			 			 if(j<10) st=st+" 0"+j+":00";
			 			 else st=st+" "+j+":00";
			           	 Date day=formatter2.parse(st);
			        	 s.setDay(day);
			         } catch(Exception e) {
			        	 System.out.println(e.getStackTrace());
			         }
			         
			         soilRepo.save(s);
				 }
			 } 
		 }
		 
		 LOG.info("Associating soil and meteo conditions to the farms... ");
		 for(int i=0; i<7; i++) {
			 Farmer farmer=farmerRepo.findByEmail(names[i]+surnames[i]+"@gmail.com");
			 farmerService.associateSoilCondition(farmer.getId());
			 farmerService.associateMeteoCondition(farmer.getId());
		 }
		 
		 LOG.info("HelpRequestForm table... adding new data");
		 for(int i=0; i<7; i++) {
			 Farmer farmer=farmerRepo.findByEmail(names[i]+surnames[i]+"@gmail.com");
			 if(farmer.getStatus().equals("BAD")) {
				 HelpRequestFormDTO hrf=new HelpRequestFormDTO();
				 hrf.setProblemDescription("help me, i have a problem");
				 hrf.setAskedBy(new FarmerDTO(farmer));
				 helpRequestsService.addHelpRequestForm(hrf);
			 }
		 }
		 
		 LOG.info("Message table... adding new data");		
		 for(int i=0; i<7; i++){
			 Farmer farmer=farmerRepo.findByEmail(names[i]+surnames[i]+"@gmail.com");
			 Message msg=new Message();
			 msg.setSender(null);
			 msg.setReceiver(farmer);
			 msg.setTime(new Date());
			 if(farmer.getStatus().equals("GOOD")) { 
				 msg.setText("Can you upload a suggestion?");
				 messageRepo.save(msg);
			 }
			 else if(farmer.getStatus().equals("BAD")) {
				 msg.setText("You can ask for help filling an help request form");
				 messageRepo.save(msg);
			 }
			
		 }
		 
		 LOG.info("UsedProduct and Product tables... adding new data");
		 String[] usedProducts= {"fertilizer1", "mattock1", "shovel1", "fertilizer2", "mattock2", "excavator", "pesticide"};
		 String[] products= {"rice", "tomatoe", "wheat", "potato", "sugar cane", "apple", "pepper"};
		 for(int i=0; i<7; i++){
			 Farmer farmer=farmerRepo.findByEmail(names[i]+surnames[i]+"@gmail.com");
			 for(int j=0; j<Math.random()*4; j++) {
				 ProductQuantityDTO production =new ProductQuantityDTO();
				 production.setProductName(products[(int)(Math.random()*7)]);
				 production.setQuantity(Math.round((Math.random()*100+20)*100.0)/100.0);
				 production.setFarmer(new FarmerDTO(farmer));
				 infoService.updateUsedProduct(farmer.getId(), usedProducts[(int)(Math.random()*7)]);
				 infoService.addProduction(production, farmer.getId());
			 }
		 }
		 
		 LOG.info("Suggestion table... adding new data");
		 for(int i=0; i<7; i++) {
			 Farmer farmer=farmerRepo.findByEmail(names[i]+surnames[i]+"@gmail.com");
			 if(farmer.getStatus().equals("GOOD")) {
				 SuggestionDTO sugg=new SuggestionDTO();
				 sugg.setUploadedBy(new FarmerDTO(farmer));
				 sugg.setText("Hi, I'm "+farmer.getName()+" my suggestion is...");
				 suggestionService.addSuggestion(sugg);
			 }
		}
		
		LOG.info("DiscussionForum table... adding new data");
		String[] topics= {"facing bad weather", "rice cultivation", "fertilizer usage"};
		for(int i=0; i<3; i++) {
			Farmer farmer=farmerRepo.findByEmail(names[i]+surnames[i]+"@gmail.com");
			DiscussionForumDTO forum= new DiscussionForumDTO();
			forum.setCreatedBy(new FarmerDTO(farmer));
			forum.setTopic(topics[i]);
			discussionService.addDiscussionForum(farmer.getId(), forum);
		}
		LOG.info("ForumPost table... adding new data");
	    for(int i=0; i<3;i++) {
	    	ForumPostDTO post=new ForumPostDTO();
	    	post.setText("some post");
	    	discussionService.addForumPost(farmerRepo.findByEmail(names[i]+surnames[i]+"@gmail.com").getId(), discussionService.searchDiscussionByTopic(topics[i]).get(0).getId(), post);
	    }
	    }
		
		
		
	}
	 
}
