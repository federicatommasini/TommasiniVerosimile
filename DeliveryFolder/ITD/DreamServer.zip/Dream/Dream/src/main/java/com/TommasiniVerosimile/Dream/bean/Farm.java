package com.TommasiniVerosimile.Dream.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.TommasiniVerosimile.Dream.modelDTO.FarmDTO;


@Entity
@Table(name="Farm")
public class Farm {
 
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer id;
	private String name;
	
	private String soilCondition;
	
	private String meteoCondition;
	
	private String city;
	
    private String geographicalZone;
    
    private Integer size;
    
    @OneToOne( mappedBy="farm")
	private Farmer farmer;
	
	public Farm() {
		super();
	}
	public Farm(Integer id, String name, String soilCondition, String meteoCondition, String city, String geographicalZone) {
		super();
		this.id = id;
		this.name = name;
		this.soilCondition = soilCondition;
		this.meteoCondition = meteoCondition;
		this.city = city;
		this.geographicalZone = geographicalZone;
	}
	
	public Farm(FarmDTO farm) {
		name=farm.getName();
		soilCondition=farm.getSoilCondition();
		meteoCondition=farm.getMeteoCondition();
		city=farm.getCity();
		geographicalZone=farm.getGeographicalZone();
		size=farm.getSize();
	}

	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getSoilCondition() {
		return soilCondition;
	}
	
	public void setSoilCondition(String soilCondition) {
		this.soilCondition = soilCondition;
	}
	
	public String getMeteoCondition() {
		return meteoCondition;
	}
	
	public void setMeteoCondition(String meteoCondition) {
		this.meteoCondition = meteoCondition;
	}
	
	public String getCity() {
		return city;
	}
	
	public void setCity(String city) {
		this.city = city;
	}
	
	public String getGeographicalZone() {
		return geographicalZone;
	}
	
	public void setGeographicalZone(String geographicalZone) {
		this.geographicalZone = geographicalZone;
	}
	public Integer getSize() {
		return size;
	}
	public void setSize(Integer size) {
		this.size = size;
	}
	public Farmer getFarmer() {
		return farmer;
	}
	public void setFarmer(Farmer farmer) {
		this.farmer = farmer;
	}
	
}

