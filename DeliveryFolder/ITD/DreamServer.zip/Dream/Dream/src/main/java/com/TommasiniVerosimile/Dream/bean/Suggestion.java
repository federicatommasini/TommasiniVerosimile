package com.TommasiniVerosimile.Dream.bean;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.TommasiniVerosimile.Dream.modelDTO.SuggestionDTO;

@Entity
@Table(name="Suggestion")
public class Suggestion {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer id;
	
	private String text;
	
	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="uploadedBy")
	private Farmer uploadedBy;

	public Suggestion() {
		super();
	}

	public Suggestion(Integer id, String text, Farmer uploadedBy) {
		super();
		this.id = id;
		this.text = text;
		this.uploadedBy = uploadedBy;
	}
	
	public Suggestion(SuggestionDTO sg) {
		id = sg.getId();
		text = sg.getText();
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public Farmer getUploadedBy() {
		return uploadedBy;
	}

	public void setUploadedBy(Farmer uploadedBy) {
		this.uploadedBy = uploadedBy;
	}
	
	
	
}
