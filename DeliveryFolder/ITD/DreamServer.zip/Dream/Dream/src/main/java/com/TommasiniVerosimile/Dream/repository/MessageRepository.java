package com.TommasiniVerosimile.Dream.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.TommasiniVerosimile.Dream.bean.Farmer;
import com.TommasiniVerosimile.Dream.bean.Message;

public interface MessageRepository extends CrudRepository<Message,Integer>{

	@Query("select m from Message m where m.receiver= :f order by m.time desc")
	public List<Message> findByFarmer(@Param("f") Farmer farmer);
	
	@Query("select m from Message m where m.id=:id")
	public Message findMessageById(@Param("id") Integer id);
}
