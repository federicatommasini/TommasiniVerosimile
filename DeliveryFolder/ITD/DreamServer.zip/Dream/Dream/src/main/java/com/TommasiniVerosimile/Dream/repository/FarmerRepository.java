package com.TommasiniVerosimile.Dream.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.TommasiniVerosimile.Dream.bean.Farmer;
import com.TommasiniVerosimile.Dream.bean.UsedProduct;

public interface FarmerRepository extends CrudRepository<Farmer,Integer>{
	
	@Query("select f from Farmer f where f.email=:em")
	public Farmer findByEmail(@Param("em") String email);
	
	@Query("select f from Farmer f where f.email=:em and f.pw=:pass")
	public Farmer findByEmailAndPw(@Param("em") String email, @Param("pass") String pw);
	
	@Query("select f from Farmer f join Farm fa on fa.id=f.farm where fa.geographicalZone= :zone")
	public List<Farmer> findByZone(@Param("zone") String geographicalZone);
	
	@Query("select f from Farmer f join Farm fa on fa.id=f.farm where fa.soilCondition= :c1 or fa.soilCondition= :c2")
	public List<Farmer> findBySoilCondition(@Param("c1") String cond1, @Param("c2") String cond2);
	
	@Query("select f from Farmer f join Farm fa on fa.id=f.farm where fa.soilCondition= :c1 or fa.soilCondition= :c2 or fa.soilCondition= :c3")
	public List<Farmer> findBySoilCondition(@Param("c1") String cond1, @Param("c2") String cond2, @Param("c3") String cond3);
	
	@Query("select f from Farmer f join Farm fa on fa.id=f.farm where fa.meteoCondition= :c1 or fa.meteoCondition= :c2")
	public List<Farmer> findByMeteoCondition(@Param("c1") String cond1, @Param("c2") String cond2);
	
	@Query("select f from Farmer f join Farm fa on fa.id=f.farm where fa.meteoCondition= :c1 or fa.meteoCondition= :c2 or fa.meteoCondition= :c3")
	public List<Farmer> findByMeteoCondition(@Param("c1") String cond1, @Param("c2") String cond2, @Param("c3") String cond3);
	
	@Query("Select f from Farmer f where :prod member of f.usedProducts")
    public List<Farmer> findByUsedProducts(@Param("prod") UsedProduct p);
	
	@Query("select f from Farmer f where f.status= :stat")
	public List<Farmer> findByStatus(@Param("stat") String status);
	
	@Query("select f from Farmer f where f.id= :i")
	public Farmer findFarmerById(@Param("i") Integer id);
}