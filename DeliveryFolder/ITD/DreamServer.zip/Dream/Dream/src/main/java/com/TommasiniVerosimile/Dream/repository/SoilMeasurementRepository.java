package com.TommasiniVerosimile.Dream.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.TommasiniVerosimile.Dream.bean.SoilMeasurement;

public interface SoilMeasurementRepository extends CrudRepository<SoilMeasurement,Integer>{

	@Query("select s from SoilMeasurement s where (s.day between :d2 and :d) and s.location= :l")
	public List<SoilMeasurement> findByDayAndLocationLastMonth(@Param("d") Date day, @Param("d2") Date day2, @Param("l") String location);

}
