package com.TommasiniVerosimile.Dream.modelDTO;

import java.util.Date;

import com.TommasiniVerosimile.Dream.bean.SoilMeasurement;

public class SoilMeasurementDTO {
	
	private Integer id;
	private Date day;
	private String location;
	private Double humidity;
	
	public SoilMeasurementDTO() {
		super();
	}
	
	public SoilMeasurementDTO(SoilMeasurement sm) {
		id = sm.getId();
		day = sm.getDay();
		location = sm.getLocation();
		humidity = sm.getHumidity();
	}
	
	public SoilMeasurement getSoilMeasurementFromDTO() {
		SoilMeasurement soilmeas=new SoilMeasurement();
		soilmeas.setDay(day);
		soilmeas.setHumidity(humidity);
		soilmeas.setLocation(location);
		return soilmeas;
	}
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Date getDay() {
		return day;
	}
	public void setDay(Date day) {
		this.day = day;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public Double getHumidity() {
		return humidity;
	}
	public void setHumidity(Double humidity) {
		this.humidity = humidity;
	}
	
	

}
