package com.TommasiniVerosimile.Dream.modelDTO;


import com.TommasiniVerosimile.Dream.bean.Farm;

public class FarmDTO {

	private Integer id;
	private String name;
	private String soilCondition;
	private String meteoCondition;
	private String city;
	private String geographicalZone;
	private Integer size;
	//private FarmerDTO farmer;
	
	public FarmDTO() {
		super();
	}
	
	public FarmDTO(Farm farm) {
		id=farm.getId();
		name=farm.getName();
		soilCondition=farm.getSoilCondition();
		meteoCondition=farm.getMeteoCondition();
		city=farm.getCity();
		geographicalZone=farm.getGeographicalZone();
		size=farm.getSize();
	}
	
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSoilCondition() {
		return soilCondition;
	}
	public void setSoilCondition(String soilCondition) {
		this.soilCondition = soilCondition;
	}
	public String getMeteoCondition() {
		return meteoCondition;
	}
	public void setMeteoCondition(String meteoCondition) {
		this.meteoCondition = meteoCondition;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getGeographicalZone() {
		return geographicalZone;
	}
	public void setGeographicalZone(String geographicalZone) {
		this.geographicalZone = geographicalZone;
	}
	public Integer getSize() {
		return size;
	}
	public void setSize(Integer size) {
		this.size = size;
	}

	
}
