package com.TommasiniVerosimile.Dream.service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.TommasiniVerosimile.Dream.bean.Farmer;
import com.TommasiniVerosimile.Dream.bean.MeteoForecast;
import com.TommasiniVerosimile.Dream.bean.SoilMeasurement;
import com.TommasiniVerosimile.Dream.modelDTO.FarmerDTO;
import com.TommasiniVerosimile.Dream.repository.FarmerRepository;
import com.TommasiniVerosimile.Dream.repository.MeteoForecastRepository;
import com.TommasiniVerosimile.Dream.repository.SoilMeasurementRepository;
import com.TommasiniVerosimile.Dream.bean.Farm;
import com.TommasiniVerosimile.Dream.repository.FarmRepository;

@Service
public class FarmerLoginService {

	@Autowired
	public FarmerRepository farmerRepo;
	
	@Autowired
	public FarmRepository farmRepo;
	
	@Autowired
	public MeteoForecastRepository meteoRepo;
	
	@Autowired
	public SoilMeasurementRepository soilRepo;
	
	
	public FarmerDTO login(String email, String password){
		Farmer farmer=farmerRepo.findByEmailAndPw(email, password); 
		if(farmer!=null) {
			FarmerDTO farmerDTO= new FarmerDTO(farmer);
			return farmerDTO;
		}
		return null;
	}
	
	public boolean checkRegCredentials(String email){
		Farmer farmer=farmerRepo.findByEmail(email);
		if(farmer==null)
			return true;
		
		else return false;
	}
	
	public FarmerDTO registration(FarmerDTO farmerDTO){
		Farmer farmer= new Farmer(farmerDTO);
		farmer.setPw(farmerDTO.getPw());
		Farm farm=new Farm(farmerDTO.getFarm());
		farm.setFarmer(farmer);
		farmer.setFarm(farm);
		List<String> cities=new ArrayList<String>();
		for(Farm f: farmRepo.findAll()) {
			cities.add(f.getCity());
		}
		boolean checkIfCityExists=false;
		for(String c : cities) {
			if(c.equals(farm.getCity())) { 
				checkIfCityExists=true;
				break;
			}
		}
		if(checkIfCityExists==false) associateValuesToCity(farm.getCity());
		farmerRepo.save(farmer);
		farmRepo.save(farm);
		farmerDTO.setId(farmer.getId());
		return farmerDTO;
	}
	
	public void associateValuesToCity(String city) {
		for(int i=-30; i<15; i++) {
			 for(int j=0; j<24; j++) {
			 MeteoForecast m=new MeteoForecast();
			 m.setTemperature(Math.round((Math.random()*28+12)*100.0)/100.0);
			 m.setRainfalls(Math.round((Math.random()*2)*100.0)/100.0);
			 m.setHumidity(Math.round((Math.random()*40+20)*100.0)/100.0);
	         m.setLocation(city);
	         SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
	         SimpleDateFormat formatter2 = new SimpleDateFormat("yyyy-MM-dd HH:mm");
	 		 Calendar c=Calendar.getInstance();
	 		 Date today= new Date();
	 		 c.setTime(today);
    		 c.add(Calendar.DATE, +i);
    		 today=c.getTime();
	 		 String todayString= formatter.format(today);
	 		 try{
	 			 Date day1=formatter.parse(todayString);
	 			 String s=formatter.format(day1);
	 			 if(j<10) s=s+" 0"+j+":00";
	 			 else s=s+" "+j+":00";
	           	 Date day=formatter2.parse(s);
	        	 m.setDay(day);
	         } catch(Exception e) {
	        	 System.out.println(e.getStackTrace());
	         }
	         
	         meteoRepo.save(m);
			 } 
	   }
		
		
		for(int i=0; i<30; i++) {
			 for(int j=0; j<24; j++) {
				 SoilMeasurement s=new SoilMeasurement();
				 s.setHumidity(Math.round((Math.random()*40+50)*100.0)/100.0);
		         s.setLocation(city);
		         SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		         SimpleDateFormat formatter2 = new SimpleDateFormat("yyyy-MM-dd HH:mm");
		 		 Calendar c=Calendar.getInstance();
		 		 Date today= new Date();
		 		 c.setTime(today);
	     		 c.add(Calendar.DATE, -i);
	     		 today=c.getTime();
		 		 String todayString= formatter.format(today);
		 		 try{
		 			 Date day1=formatter.parse(todayString);
		 			 String st=formatter.format(day1);
		 			 if(j<10) st=st+" 0"+j+":00";
		 			 else st=st+" "+j+":00";
		           	 Date day=formatter2.parse(st);
		        	 s.setDay(day);
		         } catch(Exception e) {
		        	 System.out.println(e.getStackTrace());
		         }
		         
		         soilRepo.save(s);
			 }
		 } 
	}
}
