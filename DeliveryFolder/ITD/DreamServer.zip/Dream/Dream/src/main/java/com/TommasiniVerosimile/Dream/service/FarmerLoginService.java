package com.TommasiniVerosimile.Dream.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.TommasiniVerosimile.Dream.bean.Farmer;
import com.TommasiniVerosimile.Dream.modelDTO.FarmerDTO;
import com.TommasiniVerosimile.Dream.repository.FarmerRepository;

import com.TommasiniVerosimile.Dream.bean.Farm;
import com.TommasiniVerosimile.Dream.repository.FarmRepository;

@Service
public class FarmerLoginService {

	@Autowired
	public FarmerRepository farmerRepo;
	
	@Autowired
	public FarmRepository farmRepo;
	
	
	public FarmerDTO login(String email, String password){
		Farmer farmer=farmerRepo.findByEmailAndPw(email, password); 
		if(farmer!=null) {
			FarmerDTO farmerDTO= new FarmerDTO(farmer);
			return farmerDTO;
		}
		return null;
	}
	
	public boolean checkRegCredentials(String email){
		Farmer farmer=farmerRepo.findByEmail(email);
		if(farmer==null)
			return true;
		
		else return false;
	}
	
	public FarmerDTO registration(FarmerDTO farmerDTO){
		Farmer farmer= new Farmer(farmerDTO);
		farmer.setPw(farmerDTO.getPw());
		Farm farm=new Farm(farmerDTO.getFarm());
		farm.setFarmer(farmer);
		farmer.setFarm(farm);
		farmerRepo.save(farmer);
		farmRepo.save(farm);
		farmerDTO.setId(farmer.getId());
		return farmerDTO;
	}
}
