package com.TommasiniVerosimile.Dream.bean;

import java.util.ArrayList;
import java.util.List;


import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;


import com.TommasiniVerosimile.Dream.modelDTO.FarmerDTO;

 
@Entity
@Table(name="Farmer")
public class Farmer {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer id;
	
	private String email;
	
	private String name;
	
	private String surname;
	
	private String status;
	
	private String pw;
	
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="farm")
	private Farm farm;
	
	@OneToMany(mappedBy="uploadedBy")
	private List<Suggestion> suggestions= new ArrayList<Suggestion>();
	
	@OneToMany( mappedBy="askedBy")
	private List<HelpRequestForm> helpRequests= new ArrayList<HelpRequestForm>();
	
	@OneToMany( mappedBy="createdBy")
	private List<DiscussionForum> discussionforums= new ArrayList<DiscussionForum>();
	
	@OneToMany( mappedBy="writtenBy")
	private List<ForumPost> posts= new ArrayList<ForumPost>();
	
	@OneToMany( mappedBy="farmer")
	private List<ProductQuantity> productions= new ArrayList<ProductQuantity>();
	
	@OneToMany( mappedBy="sender")
	private List<Message> sentMessages= new ArrayList<Message>();
	
	@OneToMany( mappedBy="receiver")
	private List<Message> receivedMessages= new ArrayList<Message>();
	
	 
	@ManyToMany
	@JoinTable(
		name="farmerusedproduct"
		, joinColumns={
			@JoinColumn(name="idFarmer")
			}
		, inverseJoinColumns={
			@JoinColumn(name="idUsedProduct")
			}
		)
	private List<UsedProduct> usedProducts= new ArrayList<UsedProduct>();
	
	
	public Farmer() {
		super();
	}

	public Farmer(FarmerDTO farmer) {
		email=farmer.getEmail();
		name=farmer.getName();
		surname=farmer.getSurname();
		pw=farmer.getPw();
		status="NORMAL";
		/*Farm farm2 = new Farm(farmer.getFarm());
		farm2.setFarmer(this);
		farm=farm2;*/
	}
	

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSurname() {
		return surname;
	}

	public void setSurname(String surname) {
		this.surname = surname;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getPw() {
		return pw;
	}

	public void setPw(String pw) {
		this.pw = pw;
	}

	public Farm getFarm() {
		return farm;
	}

	public void setFarm(Farm farm) {
		this.farm = farm;
	}

	public List<Suggestion> getSuggestions() {
		return suggestions;
	}

	public void setSuggestions(List<Suggestion> suggestions) {
		this.suggestions = suggestions;
	}

	public List<HelpRequestForm> getHelpRequests() {
		return helpRequests;
	}

	public void setHelpRequests(List<HelpRequestForm> helpRequests) {
		this.helpRequests = helpRequests;
	}

	public List<DiscussionForum> getDiscussionforums() {
		return discussionforums;
	}

	public void setDiscussionforums(List<DiscussionForum> discussionforums) {
		this.discussionforums = discussionforums;
	}

	public List<ForumPost> getPosts() {
		return posts;
	}

	public void setPosts(List<ForumPost> posts) {
		this.posts = posts;
	}

	public List<ProductQuantity> getProductions() {
		return productions;
	}

	public void setProductions(List<ProductQuantity> productions) {
		this.productions = productions;
	}

	public List<Message> getSentMessages() {
		return sentMessages;
	}

	public void setSentMessages(List<Message> sentMessages) {
		this.sentMessages = sentMessages;
	}

	public List<Message> getReceivedMessages() {
		return receivedMessages;
	}

	public void setReceivedMessages(List<Message> receivedMessages) {
		this.receivedMessages = receivedMessages;
	}

	public List<UsedProduct> getUsedProducts() {
		return usedProducts;
	}

	public void setUsedProducts(List<UsedProduct> usedProducts) {
		this.usedProducts = usedProducts;
	}
		
	
}