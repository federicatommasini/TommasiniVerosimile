package com.TommasiniVerosimile.Dream.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.TommasiniVerosimile.Dream.bean.DiscussionForum;
import com.TommasiniVerosimile.Dream.bean.Farmer;
import com.TommasiniVerosimile.Dream.repository.DiscussionForumRepository;
import com.TommasiniVerosimile.Dream.repository.FarmerRepository;
import com.TommasiniVerosimile.Dream.bean.ForumPost;
import com.TommasiniVerosimile.Dream.modelDTO.DiscussionForumDTO;
import com.TommasiniVerosimile.Dream.modelDTO.ForumPostDTO;
import com.TommasiniVerosimile.Dream.repository.ForumPostRepository;

@Service
public class DiscussionForumService {
	
	
	@Autowired
	public DiscussionForumRepository discussionForumRepo;
	
	@Autowired
	public ForumPostRepository forumPostRepo;
	
	@Autowired
	public FarmerRepository farmerRepo;

	public void addDiscussionForum(Integer idFarmer, DiscussionForumDTO discussionForumDTO) {
		Farmer farmer=farmerRepo.findFarmerById(idFarmer);
		DiscussionForum discussionForum= new DiscussionForum(discussionForumDTO);
		discussionForum.setCreatedBy(farmer);
		discussionForumRepo.save(discussionForum);
	}
	
	public void addForumPost(Integer idFarmer, Integer idForum, ForumPostDTO forumPostDTO) {
		DiscussionForum forum=discussionForumRepo.searchById(idForum);
		Farmer farmer=farmerRepo.findFarmerById(idFarmer);
		ForumPost forumPost= new ForumPost(forumPostDTO);
		forumPost.setWrittenBy(farmer);
		forumPost.setBelongsTo(forum);
		forumPostRepo.save(forumPost);
	}
	
	public List<DiscussionForumDTO> searchDiscussionByTopic(String topic){
		List<DiscussionForum> discussionForums= new ArrayList<DiscussionForum>();
		List<DiscussionForumDTO> discussionForumsDTO= new ArrayList<DiscussionForumDTO>();
		discussionForums= discussionForumRepo.findByTopic(topic+"%");
		for(DiscussionForum d:discussionForums) {
			discussionForumsDTO.add(new DiscussionForumDTO(d));
		}
		return discussionForumsDTO;
	}

	
}