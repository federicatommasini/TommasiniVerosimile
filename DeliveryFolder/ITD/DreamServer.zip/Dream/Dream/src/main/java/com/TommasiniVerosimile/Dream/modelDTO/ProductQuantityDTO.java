package com.TommasiniVerosimile.Dream.modelDTO;


import com.TommasiniVerosimile.Dream.bean.ProductQuantity;

public class ProductQuantityDTO {

	
	private Integer id;
	private String productName;
	private Double quantity;
	private FarmerDTO farmer;
	
	public ProductQuantityDTO() {
		super();
	}
	
	public ProductQuantityDTO(ProductQuantity pq) {
		id = pq.getId();
		productName = pq.getProduct().getName();
		farmer = new FarmerDTO(pq.getFarmer());
		quantity = pq.getQuantity();
	}
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public FarmerDTO getFarmer() {
		return farmer;
	}
	public void setFarmer(FarmerDTO farmer) {
		this.farmer = farmer;
	}
	public Double getQuantity() {
		return quantity;
	}
	public void setQuantity(Double quantity) {
		this.quantity = quantity;
	}
	
	
}
