package com.TommasiniVerosimile.Dream.bean;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="SoilMeasurement")
public class SoilMeasurement {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer id;
	
	private Date day;
	
	private String location;
		
	private Double humidity;

	public SoilMeasurement() {
		super();
	}

	public SoilMeasurement(Integer id, Date day, String location, Double humidity) {
		super();
		this.id = id;
		this.day = day;
		this.location = location;
		this.humidity = humidity;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Date getDay() {
		return day;
	}

	public void setDay(Date day) {
		this.day = day;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public Double getHumidity() {
		return humidity;
	}

	public void setHumidity(Double humidity) {
		this.humidity = humidity;
	}
	
	
	
}
