package com.TommasiniVerosimile.Dream.modelDTO;

import java.text.SimpleDateFormat;

import com.TommasiniVerosimile.Dream.bean.MeteoForecast;

public class MeteoForecastDTO {

	private Integer id;
	private String day;
	private String location;
	private Double temperature;
	private Double humidity;
	private Double rainfalls;
	
	/*public MeteoForecast getMeteoForecastFromDTO(){
		MeteoForecast meteo=new MeteoForecast();
		meteo.setDay(day);
		meteo.setLocation(location);
		meteo.setTemperature(temperature);
		meteo.setHumidity(humidity);
		meteo.setRainfalls(rainfalls);
		return meteo;
	}*/
	
	public MeteoForecastDTO() {
		super();
	}
	
	public MeteoForecastDTO(MeteoForecast mt) {
		id = mt.getId();
		day  = (new SimpleDateFormat("yyyy-MM-dd HH:mm")).format(mt.getDay());
		location = mt.getLocation();
		temperature = mt.getTemperature();
		humidity = mt.getHumidity();
		rainfalls = mt.getRainfalls();
	}
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getDay() {
		return day;
	}
	public void setDay(String day) {
		this.day = day;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public Double getTemperature() {
		return temperature;
	}
	public void setTemperature(Double temperature) {
		this.temperature = temperature;
	}
	public Double getHumidity() {
		return humidity;
	}
	public void setHumidity(Double humidity) {
		this.humidity = humidity;
	}
	public Double getRainfalls() {
		return rainfalls;
	}
	public void setRainfalls(Double rainfalls) {
		this.rainfalls = rainfalls;
	}
	
	
}
