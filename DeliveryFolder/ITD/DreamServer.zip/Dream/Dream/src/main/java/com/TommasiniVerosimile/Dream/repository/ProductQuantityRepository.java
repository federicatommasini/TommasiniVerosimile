package com.TommasiniVerosimile.Dream.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.TommasiniVerosimile.Dream.bean.Farmer;
import com.TommasiniVerosimile.Dream.bean.Product;
import com.TommasiniVerosimile.Dream.bean.ProductQuantity;

public interface ProductQuantityRepository extends CrudRepository<ProductQuantity,Integer>{

	@Query("select p from ProductQuantity p where p.farmer= :far")
	public List<ProductQuantity> searchByFarmer(@Param("far") Farmer f);
	
	@Query("select p from ProductQuantity p where p.farmer= :far and p.product= :prod")
	public ProductQuantity searchByFarmerAndProduct(@Param("far") Farmer farmer, @Param("prod") Product product);

}
