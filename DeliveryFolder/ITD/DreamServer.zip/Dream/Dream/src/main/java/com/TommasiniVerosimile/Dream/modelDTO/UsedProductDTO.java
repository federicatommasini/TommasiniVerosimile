package com.TommasiniVerosimile.Dream.modelDTO;

import java.util.ArrayList;
import java.util.List;

import com.TommasiniVerosimile.Dream.bean.Farmer;
import com.TommasiniVerosimile.Dream.bean.UsedProduct;

public class UsedProductDTO {

	private Integer id;
	private String name;
	private List<FarmerDTO> farmers=new ArrayList<FarmerDTO>();
	
	public UsedProductDTO() {
		super();
	}
	
	public UsedProductDTO(UsedProduct up){
		id = up.getId();
		name = up.getName();
		for(Farmer f: up.getFarmers()) {
		    farmers.add(new FarmerDTO(f)); 
		}
	}
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List<FarmerDTO> getFarmers() {
		return farmers;
	}
	public void setFarmers(List<FarmerDTO> farmers) {
		this.farmers = farmers;
	}
	
	
}
