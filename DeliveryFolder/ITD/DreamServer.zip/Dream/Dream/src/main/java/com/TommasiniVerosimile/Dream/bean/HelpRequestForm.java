package com.TommasiniVerosimile.Dream.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.TommasiniVerosimile.Dream.modelDTO.HelpRequestFormDTO;

@Entity
@Table(name="HelpRequestForm")
public class HelpRequestForm {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer id;
	
	private String problemDescription;
	
	@ManyToOne
	@JoinColumn(name="askedBy")
	private Farmer askedBy;

	public HelpRequestForm() {
		super();
	}

	public HelpRequestForm(Integer id, String problemDescription, Farmer askedBy) {
		super();
		this.id = id;
		this.problemDescription = problemDescription;
		this.askedBy = askedBy;
	}
	
	public HelpRequestForm(HelpRequestFormDTO hrf) {
		//id = hrf.getId();
		problemDescription = hrf.getProblemDescription();
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getProblemDescription() {
		return problemDescription;
	}

	public void setProblemDescription(String problemDescription) {
		this.problemDescription = problemDescription;
	}

	public Farmer getAskedBy() {
		return askedBy;
	}

	public void setAskedBy(Farmer askedBy) {
		this.askedBy = askedBy;
	}
	
	
	
}
