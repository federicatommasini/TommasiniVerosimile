package com.TommasiniVerosimile.Dream.modelDTO;


import com.TommasiniVerosimile.Dream.bean.Farmer;

public class FarmerDTO {

	private Integer id;
	private String email;
	private String name;
	private String surname;
	private String status;
	private String pw;
	private FarmDTO farm;
	
	public FarmerDTO() {
		super();
	}
	
	public FarmerDTO(Farmer farmer) {
		id = farmer.getId();
		email = farmer.getEmail();
		name = farmer.getName();
		surname = farmer.getSurname();
		status = farmer.getStatus();
		pw = farmer.getPw();
		farm = new FarmDTO(farmer.getFarm());
				
		
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSurname() {
		return surname;
	}

	public void setSurname(String surname) {
		this.surname = surname;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getPw() {
		return pw;
	}

	public void setPw(String pw) {
		this.pw = pw;
	}

	public FarmDTO getFarm() {
		return farm;
	}

	public void setFarm(FarmDTO farm) {
		this.farm = farm;
	}
	
}
