package com.TommasiniVerosimile.Dream.modelDTO;

import java.util.Date;

import com.TommasiniVerosimile.Dream.bean.Message;

public class MessageDTO {

	private Integer id;
	private String text;
	private Date time;
	private FarmerDTO sender;
	private FarmerDTO receiver;
	private int answered;
	private int request;

	public MessageDTO() {
		super();
	}

	public MessageDTO(Message msg) {
		id = msg.getId();
		text = msg.getText();
		time = msg.getTime();
		answered=msg.getAnswered();
		request=msg.getRequest();
		if (msg.getSender() != null) {
			sender = new FarmerDTO(msg.getSender());
		}else sender=null;
		receiver = new FarmerDTO(msg.getReceiver());
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public Date getTime() {
		return time;
	}

	public void setTime(Date time) {
		this.time = time;
	}

	public FarmerDTO getSender() {
		return sender;
	}

	public void setSender(FarmerDTO sender) {
		this.sender = sender;
	}

	public FarmerDTO getReceiver() {
		return receiver;
	}

	public void setReceiver(FarmerDTO receiver) {
		this.receiver = receiver;
	}

	public int getAnswered() {
		return answered;
	}

	public void setAnswered(int answered) {
		this.answered = answered;
	}

	public int getRequest() {
		return request;
	}

	public void setRequest(int request) {
		this.request = request;
	}

}
